#!/usr/bin/env python3
"""공장 ② 배포 — 카탈로그를 비밀번호 뒤에 올린다 (Cloudflare Pages).

  deploy.py 수집/아오스타            한 브랜드를 올린다
  deploy.py --all                   수집 폴더의 모든 브랜드 + 홈 목록

만드는 것 (배포용 임시 폴더 `.배포/`):
  .배포/<브랜드>/index.html          카탈로그
  .배포/<브랜드>/이미지/…             사진 (원본 복사)
  .배포/index.html                   브랜드 목록 (홈)
  .배포/functions/_middleware.js     비밀번호 문 — 서버에서 막는다

비밀번호는 Cloudflare 쪽 환경변수(CATALOG_PW)로만 들어가고, 페이지 파일에는 적히지 않는다.
"""

import sys as _sys
for _s in (_sys.stdout, _sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
import argparse, datetime, html, json, os, pathlib, shutil, subprocess, sys

sys.path.insert(0, str(pathlib.Path(__file__).parent))
import settings as st
import build_catalog as bc

MIDDLEWARE = r"""// 비밀번호 문 — Cloudflare Pages Functions.
// 쿠키가 없으면 어떤 파일도(사진 포함) 내주지 않는다.
const COOKIE = "cat_pass";

async function sign(pw, secret) {
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const sig = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(pw));
  return [...new Uint8Array(sig)].map(b => b.toString(16).padStart(2, "0")).join("");
}

const FORM = (msg) => `<!doctype html><html lang="ko"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>비밀번호</title>
<style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#f6f4f0;
color:#231f1b;font:16px/1.6 -apple-system,"Malgun Gothic",system-ui,sans-serif}
form{width:min(90vw,340px);background:#fff;padding:30px 26px;border-radius:18px;
box-shadow:0 10px 40px rgba(0,0,0,.08);text-align:center}
h1{font-size:18px;margin:0 0 6px}p{margin:0 0 18px;color:#8a8079;font-size:14px}
input{width:100%;padding:13px;font-size:16px;border:1px solid #e2dbd3;border-radius:11px;
text-align:center;margin-bottom:10px}
button{width:100%;padding:13px;font-size:16px;font-weight:600;border:0;border-radius:11px;
background:#231f1b;color:#fff;cursor:pointer}
.err{color:#b3392f;font-size:14px;margin-bottom:10px}
@media(prefers-color-scheme:dark){body{background:#1b1917;color:#f2ece5}
form{background:#252220;box-shadow:none}input{background:#1b1917;color:#f2ece5;border-color:#3a3531}
button{background:#f2ece5;color:#231f1b}p{color:#a69c91}}</style></head><body>
<form method="POST"><h1>공동구매 카탈로그</h1><p>방 공지의 비밀번호를 넣어주세요</p>
${msg ? `<div class="err">${msg}</div>` : ""}
<input type="password" name="pw" autofocus autocomplete="current-password">
<button type="submit">들어가기</button></form></body></html>`;

export async function onRequest(context) {
  const { request, env, next } = context;
  const pw = env.CATALOG_PW;
  if (!pw) {
    // 비밀번호가 등록되지 않았다면 열어주지 않는다.
    // (열어주면 도매처 사진과 판매가가 통째로 공개된다)
    return new Response("준비 중입니다. 잠시 뒤 다시 들어와 주세요.",
      { status: 503, headers: { "Content-Type": "text/plain; charset=utf-8" } });
  }
  const token = await sign(pw, "kv-catalog-v1");
  const cookie = request.headers.get("Cookie") || "";
  if (cookie.includes(`${COOKIE}=${token}`)) return next();

  if (request.method === "POST") {
    const form = await request.formData();
    if ((form.get("pw") || "").trim() === pw) {
      return new Response(null, { status: 303, headers: {
        "Location": new URL(request.url).pathname,
        "Set-Cookie": `${COOKIE}=${token}; Path=/; Max-Age=2592000; HttpOnly; Secure; SameSite=Lax`,
      }});
    }
    return new Response(FORM("비밀번호가 맞지 않습니다"), { status: 401,
      headers: { "Content-Type": "text/html; charset=utf-8" } });
  }
  return new Response(FORM(""), { status: 401,
    headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store" } });
}
"""

HOME = """<!doctype html><html lang="ko"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow"><title>{room}</title>
<style>
:root{{--bg:#faf8f5;--card:#fff;--ink:#1d1b19;--mute:#7a736b;--line:#e9e3db;--accent:#e0554a}}
@media(prefers-color-scheme:dark){{:root{{--bg:#1b1917;--card:#252220;--ink:#f2ece5;
--mute:#a69c91;--line:#3a3531;--accent:#f08b82}}}}
*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--ink);
font:16px/1.6 -apple-system,"Malgun Gothic","Apple SD Gothic Neo",system-ui,sans-serif}}
.w{{max-width:760px;margin:0 auto;padding:28px 18px 60px}}
h1{{font-size:22px;margin:0 0 4px}}.sub{{color:var(--mute);font-size:14px;margin:0 0 24px}}
a.b{{display:flex;justify-content:space-between;align-items:center;gap:12px;
background:var(--card);border:1px solid var(--line);border-radius:14px;padding:18px 20px;
margin-bottom:10px;text-decoration:none;color:inherit}}
a.b:hover{{border-color:var(--accent)}}
.n{{font-weight:700;font-size:17px}}.c{{color:var(--mute);font-size:13px}}
.arrow{{color:var(--accent);font-weight:700}}
</style></head><body><div class="w">
<h1>{room}</h1><p class="sub">브랜드를 눌러 상품을 보세요 · {date} 기준</p>
{rows}
</div></body></html>"""


def find_npx() -> str:
    """npx 를 찾는다. 방금 Node 를 설치한 창에서는 PATH 가 아직 갱신되지 않으므로
    표준 설치 경로까지 직접 살펴본다."""
    found = shutil.which("npx") or shutil.which("npx.cmd")
    if found:
        return found
    for c in (r"C:\Program Files\nodejs\npx.cmd",
              r"C:\Program Files (x86)\nodejs\npx.cmd",
              str(pathlib.Path.home() / "AppData/Roaming/npm/npx.cmd"),
              "/opt/homebrew/bin/npx", "/usr/local/bin/npx"):
        if pathlib.Path(c).exists():
            return c
    sys.exit("⛔ 인터넷에 올리는 프로그램(Node.js)을 찾지 못했습니다.\n"
             "   1) ChatGPT 앱을 완전히 껐다가 다시 켜보세요 (대부분 이걸로 해결됩니다)\n"
             "   2) 그래도 안 되면 [설치하기] 를 한 번 더 더블클릭해 주세요\n"
             "   3) 여전하면 이 화면을 캡처해서 강사님께 보내주세요")


def build_one(folder: pathlib.Path, out: pathlib.Path, cfg: dict, title: str = None):
    """카탈로그 HTML + 이미지를 배포 폴더에 통째로 만든다."""
    items = bc.read_master(folder)
    if not items:
        return None
    brand = str(items[0].get("브랜드") or folder.name)
    dst = out / brand
    shutil.rmtree(dst, ignore_errors=True)     # 지난번 잔재가 계속 업로드되지 않게
    dst.mkdir(parents=True, exist_ok=True)
    n_img = 0
    for p in items:
        src = folder / str(p["이미지폴더"]) / "이미지"
        if not src.exists():
            continue
        d = dst / str(p["이미지폴더"]) / "이미지"      # 수집 폴더와 같은 구조 (페이지가 이 경로를 참조한다)
        d.mkdir(parents=True, exist_ok=True)
        for f in sorted(src.glob("*.jpg")):
            t = d / f.name
            if not t.exists() or t.stat().st_size != f.stat().st_size:
                shutil.copy2(f, t)
            n_img += 1
    bc.write_page(items, dst / "index.html", title or f"{brand} {cfg.get('시즌') or '신상'}",
                  img_prefix=".", cfg=cfg)
    return {"brand": brand, "count": len(items), "images": n_img}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("folder", nargs="?", help="수집/<브랜드> 폴더")
    ap.add_argument("--all", action="store_true", help="수집 폴더의 모든 브랜드")
    ap.add_argument("--title", default=None)
    ap.add_argument("--dry-run", action="store_true", help="파일만 만들고 올리지는 않는다")
    ap.add_argument("--비밀번호갱신", dest="newpw", action="store_true",
                    help="설정.txt 의 비밀번호를 클라우드플레어에도 반영한다")
    a = ap.parse_args()

    cfg = st.load()
    root = cfg["_path"].parent
    out = root / ".배포"
    KEEP = int(cfg.get("보관브랜드수") or 8)
    if not a.folder and not a.all:
        ap.error("브랜드 폴더를 지정하거나 --all 을 쓰세요")

    targets = sorted(p for p in (root / "수집").iterdir()
                     if p.is_dir() and (p / "상품마스터.xlsx").exists()) if a.all \
        else [pathlib.Path(a.folder)]

    built = []
    for t in targets:
        r = build_one(t, out, cfg, a.title)
        if r:
            built.append(r)
            print(f"   {r['brand']} — {r['count']}종 · 사진 {r['images']}장 준비 완료")
    if not built:
        sys.exit("⛔ 올릴 브랜드가 없습니다.")

    # 오래된 브랜드는 내린다 — 한 번에 올릴 수 있는 파일 수에 한계가 있다
    brand_dirs = [d for d in out.iterdir()
                  if d.is_dir() and d.name != "functions" and (d / "index.html").exists()]
    fresh = {b["brand"] for b in built}
    others = sorted((d for d in brand_dirs if d.name not in fresh),
                    key=lambda d: d.stat().st_mtime, reverse=True)
    dropped = others[max(0, KEEP - len(fresh)):]
    for d in dropped:
        shutil.rmtree(d, ignore_errors=True)
    if dropped:
        print(f"   지난 브랜드 {len(dropped)}개는 페이지에서 내렸습니다 "
              f"(자료는 수집 폴더에 그대로 있습니다): {', '.join(d.name for d in dropped)}")

    # 홈: 지금 올라가 있는 브랜드 목록
    known = {b["brand"]: b["count"] for b in built}
    for d in sorted(out.iterdir()):
        if d.is_dir() and d.name != "functions" and (d / "index.html").exists():
            known.setdefault(d.name, 0)
    def when(b):
        d = out / b
        return d.stat().st_mtime if d.exists() else 0

    rows = "\n".join(
        f'<a class="b" href="./{html.escape(b)}/"><span><span class="n">{html.escape(b)}</span>'
        f'<br><span class="c">{"상품 " + str(c) + "종 · 오늘 올림" if c else "지난 업데이트"}</span></span>'
        f'<span class="arrow">보기 →</span></a>'
        for b, c in sorted(known.items(), key=lambda kv: (-when(kv[0]), kv[0])))
    (out / "index.html").write_text(
        HOME.format(room=html.escape(cfg["방이름"]), date=f"{datetime.date.today():%Y-%m-%d}", rows=rows),
        encoding="utf-8")

    (out / "functions").mkdir(exist_ok=True)
    (out / "functions" / "_middleware.js").write_text(MIDDLEWARE, encoding="utf-8")
    (out / "_headers").write_text("/*\n  X-Robots-Tag: noindex, nofollow\n", encoding="utf-8")

    if a.dry_run:
        print(f"\n✅ 배포 파일 준비 완료 (올리지 않음): {out}")
        return

    if a.newpw:
        npx0 = find_npx()
        project0 = cfg["페이지이름"]
        print(f"비밀번호를 새로 등록합니다 ({project0})…")
        try:
            subprocess.run([npx0, "-y", "wrangler@4", "pages", "secret", "put",
                            "CATALOG_PW", "--project-name", project0],
                           env=dict(os.environ, CI="1",
                                    npm_config_cache=str(cfg["_path"].parent / ".npm-cache")),
                           input=(cfg["비밀번호"] + "\n").encode("utf-8"),
                           capture_output=True, timeout=300)
        except subprocess.TimeoutExpired:
            sys.exit("⛔ 시간이 너무 걸려 멈췄습니다. 인터넷을 확인하고 다시 해 주세요.")
        print("✅ 비밀번호를 바꿨습니다.")
        print("   이제 방 공지의 비밀번호도 새 것으로 바꿔 주세요.")
        print("   고객분들은 다음에 들어올 때 새 비밀번호를 한 번 넣으시면 됩니다.")
        return

    gate = out / "functions" / "_middleware.js"
    if not gate.exists():
        sys.exit("⛔ 비밀번호 문 파일이 없습니다. 올리지 않았습니다.\n"
                 "   이 화면을 캡처해서 강사님께 보내주세요.")

    project = cfg["페이지이름"]
    print(f"\n인터넷에 올리는 중… (프로젝트 {project})")
    print("   처음 올리실 때는 준비 작업 때문에 3~5분쯤 조용할 수 있습니다.")
    print("   창을 닫지 말고 기다려 주세요.")
    env = dict(os.environ, CI="1")
    # [2] npx 가 쓸 수 있는 캐시 자리를 우리 폴더 안에 지정한다
    #     (기본 자리는 권한이 없어 "npm-cache 에 기록할 권한이 없다" 로 실패한다)
    cache = root / ".npm-cache"
    cache.mkdir(exist_ok=True)
    env["npm_config_cache"] = str(cache)
    npx = find_npx()

    def run(args, timeout=300, **kw):
        """wrangler 호출. stdin 을 막아 두어야 답을 기다리며 영원히 멈추지 않는다."""
        try:
            r = subprocess.run([npx, "-y", "wrangler@4", *args], env=env,
                               capture_output=True, text=True,
                               encoding="utf-8", errors="replace",
                               stdin=subprocess.DEVNULL, timeout=timeout, **kw)
        except subprocess.TimeoutExpired:
            sys.exit(f"⛔ {timeout // 60}분을 기다려도 응답이 없어 멈췄습니다.\n"
                     "   인터넷 연결을 확인하고 다시 해 주세요.\n"
                     "   계속 이러면 이 화면을 캡처해서 강사님께 보내주세요.")
        txt = (r.stdout or "") + (r.stderr or "")
        if "npm-cache" in txt or "EPERM" in txt or "EACCES" in txt:
            sys.exit("⛔ 컴퓨터의 권한 문제로 준비 파일을 만들지 못했습니다.\n"
                     "   ChatGPT 앱을 완전히 껐다가 다시 켜고 한 번 더 해 주세요.\n"
                     "   그래도 안 되면 이 화면을 캡처해서 강사님께 보내주세요.")
        if "More than one account" in txt or "Select an account" in txt:
            sys.exit("⛔ 클라우드플레어 계정이 여러 개라 어느 것을 쓸지 정해야 합니다.\n"
                     "   이 화면을 캡처해서 강사님께 보내주세요. (계정 번호를 설정에 적어드립니다)")
        return r

    # 프로젝트가 없으면 만든다 (처음 한 번)
    ls = run(["pages", "project", "list"], timeout=600)   # 첫 실행은 프로그램을 내려받느라 오래 걸린다
    if ls.returncode != 0:
        txt = (ls.stdout or "") + (ls.stderr or "")
        if "login" in txt.lower() or "auth" in txt.lower() or "credential" in txt.lower():
            sys.exit("⛔ 클라우드플레어 로그인이 필요합니다.\n"
                     "   코덱스에게 \"클라우드플레어 로그인해줘\" 라고 하세요.")
    if project not in (ls.stdout or ""):
        print(f"   페이지 자리를 만듭니다 ({project})…")
        cr = run(["pages", "project", "create", project, "--production-branch", "main"])
        if cr.returncode != 0:
            out_txt = ((cr.stdout or "") + (cr.stderr or "")).lower()
            if "already exists" in out_txt or "8000007" in out_txt:
                pass                      # 이미 있으면 그대로 쓴다
            elif "login" in out_txt or "auth" in out_txt:
                sys.exit("⛔ 클라우드플레어 로그인이 필요합니다.\n"
                         "   코덱스에게 \"클라우드플레어 로그인해줘\" 라고 하세요.")
            elif "taken" in out_txt or "unique" in out_txt or "unavailable" in out_txt:
                sys.exit(f"⛔ '{project}' 라는 주소는 이미 다른 사람이 쓰고 있습니다.\n"
                         f"   설정.txt 의 페이지이름을 다른 것으로 바꿔 주세요.\n"
                         f"   예: {project}-kids, {project}2026, sodam-baby (영문 소문자·숫자·하이픈)")
            else:
                sys.exit("⛔ 페이지 자리를 만들지 못했습니다. 이 화면을 캡처해 강사님께 보내주세요.\n"
                         f"   {((cr.stdout or '') + (cr.stderr or '')).strip()[-300:]}")

    # 비밀번호가 클라우드플레어에 등록돼 있는지 — 없으면 사진까지 공개된다
    sec = run(["pages", "secret", "list", "--project-name", project])
    if "CATALOG_PW" not in (sec.stdout or ""):
        print("   비밀번호를 클라우드플레어에 등록합니다…")
        try:
            subprocess.run([npx, "-y", "wrangler@4", "pages", "secret", "put",
                            "CATALOG_PW", "--project-name", project],
                           env=env, input=(cfg["비밀번호"] + "\n").encode("utf-8"),
                           capture_output=True, timeout=300)
        except subprocess.TimeoutExpired:
            sys.exit("⛔ 비밀번호를 등록하는 데 시간이 너무 걸려 멈췄습니다.\n"
                     "   인터넷을 확인하고 다시 해 주세요.")
        again = run(["pages", "secret", "list", "--project-name", project])
        if "CATALOG_PW" not in (again.stdout or ""):
            sys.exit("⛔ 비밀번호를 등록하지 못해 올리지 않았습니다.\n"
                     "   (비밀번호 없이 올리면 사진과 가격이 모두 공개됩니다)\n"
                     "   이 화면을 캡처해서 강사님께 보내주세요.")
    # ⚠️ wrangler 는 **현재 작업 디렉터리**의 functions/ 를 찾는다.
    #    배포 폴더 밖에서 실행하면 비밀번호 문이 통째로 빠진 채 올라간다 (사진까지 공개됨).
    cmd = [npx, "-y", "wrangler@4", "pages", "deploy", ".",
           "--project-name", project, "--branch", "main", "--commit-dirty", "true"]
    n_files = sum(1 for _ in out.rglob("*") if _.is_file())
    print(f"   사진과 페이지 {n_files:,}개를 올립니다 — 10~20분 걸립니다.")
    print("   끝나면 주소가 나옵니다. 그때까지 창을 닫지 마세요.")
    try:
        r = subprocess.run(cmd, env=env, cwd=str(out), capture_output=True, text=True,
                           encoding="utf-8", errors="replace",
                           stdin=subprocess.DEVNULL, timeout=1800)
    except subprocess.TimeoutExpired:
        sys.exit("⛔ 30분을 기다려도 끝나지 않아 멈췄습니다.\n"
                 "   인터넷이 느리거나 끊긴 것 같습니다. 잠시 뒤 다시 해 주세요.\n"
                 "   (페이지는 이전 상태 그대로 살아 있습니다)")
    log = (r.stdout or "") + (r.stderr or "")
    if r.returncode != 0:
        if "project" in log.lower() and ("not found" in log.lower() or "찾을 수" in log):
            print(f"⛔ '{project}' 프로젝트가 아직 없습니다. 처음 한 번만 만들면 됩니다:\n"
                  f"   npx wrangler@4 pages project create {project} --production-branch main")
        elif "login" in log.lower() or "auth" in log.lower():
            print("⛔ 클라우드플레어 로그인이 필요합니다. 코덱스에게 \"클라우드플레어 로그인해줘\" 라고 하세요.")
        else:
            print("⛔ 올리는 데 실패했습니다. 인터넷 연결을 확인하고 다시 시도해 주세요.")
            print("   " + log.strip().splitlines()[-1] if log.strip() else "")
        print("   (페이지는 이전 상태 그대로 살아 있습니다)")
        sys.exit(1)

    url = f"https://{project}.pages.dev"
    print(f"✅ 올라갔습니다: {url}")
    for b in built:
        print(f"   {b['brand']} — {url}/{b['brand']}")
    print("   (비밀번호는 방 공지의 그 비밀번호입니다)")


if __name__ == "__main__":
    main()
