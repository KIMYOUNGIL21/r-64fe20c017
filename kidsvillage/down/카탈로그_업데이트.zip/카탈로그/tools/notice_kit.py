#!/usr/bin/env python3
"""공장 ③ 알림 키트 — 카톡방에 올릴 재료를 폴더 하나로 만든다.

  notice_kit.py 수집/아오스타 [--out 알림키트] [--url https://...] [--picks 5]

만드는 것:
  알림키트/<날짜>_<브랜드>/
    대표컷/01_상품명.jpg …      상품마다 첫 사진 (원본 복사, 화질 그대로)
    공지문.txt                  그대로 복사해 카톡에 붙일 글

카톡 발송은 하지 않는다. "복사해서 붙이면 되는 상태"까지가 이 도구의 끝이다.
"""

import sys as _sys
for _s in (_sys.stdout, _sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
import argparse, datetime, pathlib, re, shutil, sys
import openpyxl

sys.path.insert(0, str(pathlib.Path(__file__).parent))
import settings as st



def explain_empty(folder):
    """상품이 하나도 안 잡힐 때, 왜인지 세어서 알려준다."""
    import openpyxl as _x
    f = folder / "상품마스터.xlsx"
    if not f.exists():
        return "상품마스터.xlsx 가 없습니다. 먼저 수집을 해 주세요."
    ws = _x.load_workbook(f, read_only=True).active
    rows = list(ws.iter_rows(values_only=True))
    if len(rows) < 2:
        return "상품마스터에 상품이 한 줄도 없습니다."
    hdr = rows[0]
    no_id = no_price = hidden = sold = total = 0
    states = {}
    for r in rows[1:]:
        d = dict(zip(hdr, r)); total += 1
        st = str(d.get("상태") or "").strip()
        states[st] = states.get(st, 0) + 1
        if not d.get("상품ID"): no_id += 1
        elif st == "숨김": hidden += 1
        elif st == "품절": sold += 1
        elif not (d.get("판매가_수정") or d.get("판매가_규칙")): no_price += 1
    parts = [f"상품마스터에 {total}종이 있는데 올릴 수 있는 것이 없습니다."]
    if no_id: parts.append(f"  · 상품 번호가 없는 것 {no_id}종")
    if hidden: parts.append(f"  · 숨김 {hidden}종")
    if sold: parts.append(f"  · 품절 {sold}종")
    if no_price: parts.append(f"  · 가격이 없는 것 {no_price}종")
    shown = ", ".join((k or "(빈칸)") + "=" + str(v) for k, v in states.items())
    parts.append("  · 상태 열의 값: " + shown)
    return "\n".join(parts)


def read_master(folder: pathlib.Path):
    f = folder / "상품마스터.xlsx"
    if not f.exists():
        sys.exit(f"⛔ {f} 가 없습니다. 먼저 수집을 해 주세요.")
    ws = openpyxl.load_workbook(f, read_only=True).active
    rows = list(ws.iter_rows(values_only=True))
    hdr = rows[0]
    items = []
    for r in rows[1:]:
        p = dict(zip(hdr, r))
        if not p.get("상품ID") or str(p.get("상태") or "").strip() in ("숨김", "품절"):
            continue
        price = p.get("판매가_수정") or p.get("판매가_규칙")
        if not price:
            continue
        p["price"] = int(str(price).replace(",", ""))
        imgs = sorted((folder / str(p["이미지폴더"]) / "이미지").glob("*.jpg"))
        p["first"] = imgs[0] if imgs else None
        items.append(p)
    return items


def safe(name: str) -> str:
    return re.sub(r"[^\w가-힣]+", "_", str(name)).strip("_")[:40]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("folder")
    ap.add_argument("--out", default=None, help="알림키트 폴더 (기본: 카탈로그 폴더/알림키트)")
    ap.add_argument("--url", default=None, help="카탈로그 주소. 없으면 설정의 페이지이름으로 만든다")
    ap.add_argument("--picks", type=int, default=5, help="공지문에 이름을 적을 상품 수")
    ap.add_argument("--season", default=None, help="공지 제목의 시즌 문구 (기본: 설정.txt의 시즌)")
    a = ap.parse_args()

    folder = pathlib.Path(a.folder)
    cfg = st.load()
    items = read_master(folder)
    if not items:
        sys.exit("⛔ " + explain_empty(folder) + "\n   이 화면을 캡처해서 강사님께 보내주세요.")

    brand = str(items[0].get("브랜드") or folder.name)
    today = datetime.date.today()
    base = pathlib.Path(a.out) if a.out else cfg["_path"].parent / "알림키트"
    season = a.season or cfg.get("시즌") or "신상"
    kit = base / f"{today:%Y-%m-%d}_{safe(brand)}"
    shots = kit / "대표컷"
    shots.mkdir(parents=True, exist_ok=True)

    n = 0
    for i, p in enumerate(items, 1):
        if not p["first"]:
            continue
        shutil.copy2(p["first"], shots / f"{i:02d}_{safe(p['상품명'])}.jpg")
        n += 1

    url = a.url or f"https://{cfg['페이지이름']}.pages.dev/{brand}"
    # 가격대가 골고루 보이도록 정렬 후 균등 간격으로 뽑는다 (싼 것만 나열되지 않게)
    ordered = sorted(items, key=lambda p: p["price"])
    k = min(a.picks, len(ordered))
    picks = [ordered[round(i * (len(ordered) - 1) / max(k - 1, 1))] for i in range(k)] if k > 1 else ordered[:1]
    picked = " · ".join(f"{p['상품명']} {p['price']:,}" for p in picks)

    # 카톡에 바로 첨부할 사진: 공지문에 이름이 나온 것들만 따로 모아 준다
    rec = kit / "추천컷"
    rec.mkdir(exist_ok=True)
    for i, p in enumerate(picks, 1):
        if p["first"]:
            shutil.copy2(p["first"], rec / f"{i}_{safe(p['상품명'])}.jpg")

    notice = (
        f"[{brand} {season} {len(items)}종 업데이트]\n\n"
        f"👉 {url}\n"
        f"   (비밀번호는 방 공지에 있어요)\n\n"
        f"오늘 올라온 것 중 몇 가지 — {picked}\n\n"
        f"· 사진은 페이지에서 상품마다 여러 장 보실 수 있어요.\n"
        f"· 주문은 CS채널로 \"상품명 / 색상 / 사이즈 / 수량\" 보내주세요.\n"
        f"  (페이지에서 '주문 문구 복사'를 누르면 그대로 붙여넣을 수 있어요)\n"
        f"· 배송비 {cfg['배송비']:,}원\n"
    )
    (kit / "공지문.txt").write_text(notice, encoding="utf-8")

    print(f"✅ 알림 키트: {kit}")
    print(f"   추천컷 {len(picks)}장 (공지문에 나온 상품) · 대표컷 {n}장 · 공지문.txt")
    print("   → 공지문.txt 복사해서 카톡방에 붙이고, 추천컷 폴더의 사진을 전부 첨부하시면 됩니다.")


if __name__ == "__main__":
    main()
