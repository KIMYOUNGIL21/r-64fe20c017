#!/usr/bin/env python3
"""공장 ② 카탈로그 페이지 — 상품마스터.xlsx + 이미지 폴더 → 정적 HTML 한 장.

  build_catalog.py 수집/아오스타 [--title "아오스타 26가을"] [--out 수집/아오스타/catalog]

상품마스터.xlsx 가 단일 진실: 판매자님이 '판매가_수정'·'상태'(판매중/품절/숨김) 열을 고치면 페이지가 그걸 따른다.
이미지는 상대 경로로 참조한다 (배포 시 폴더째 올린다).
"""

import sys as _sys
for _s in (_sys.stdout, _sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
import argparse, json, pathlib, html, datetime, sys
import openpyxl

sys.path.insert(0, str(pathlib.Path(__file__).parent))


def explain_empty(folder):
    """상품이 하나도 안 잡힐 때, 왜인지 세어서 알려준다."""
    import openpyxl as _x
    f = folder / "상품마스터.xlsx"
    if not f.exists():
        return "상품마스터.xlsx 가 없습니다. 먼저 수집을 해 주세요."
    ws = _x.load_workbook(f, read_only=True).active
    rows = list(ws.iter_rows(values_only=True))
    if len(rows) < 2:
        return "상품마스터에 상품이 한 줄도 없습니다."
    hdr = rows[0]
    no_id = no_price = hidden = sold = total = 0
    states = {}
    for r in rows[1:]:
        d = dict(zip(hdr, r)); total += 1
        st = str(d.get("상태") or "").strip()
        states[st] = states.get(st, 0) + 1
        if not d.get("상품ID"): no_id += 1
        elif st == "숨김": hidden += 1
        elif st == "품절": sold += 1
        elif not (d.get("판매가_수정") or d.get("판매가_규칙")): no_price += 1
    parts = [f"상품마스터에 {total}종이 있는데 올릴 수 있는 것이 없습니다."]
    if no_id: parts.append(f"  · 상품 번호가 없는 것 {no_id}종")
    if hidden: parts.append(f"  · 숨김 {hidden}종")
    if sold: parts.append(f"  · 품절 {sold}종")
    if no_price: parts.append(f"  · 가격이 없는 것 {no_price}종")
    shown = ", ".join((k or "(빈칸)") + "=" + str(v) for k, v in states.items())
    parts.append("  · 상태 열의 값: " + shown)
    return "\n".join(parts)


def read_master(folder: pathlib.Path):
    ws = openpyxl.load_workbook(folder / "상품마스터.xlsx", read_only=True).active
    rows = list(ws.iter_rows(values_only=True)); hdr = rows[0]
    items = []
    for r in rows[1:]:
        p = dict(zip(hdr, r))
        p["상태"] = str(p.get("상태") or "판매중").strip()
        if not p.get("상품ID") or p["상태"] == "숨김":
            continue
        imgdir = folder / p["이미지폴더"] / "이미지"
        p["images"] = sorted(x.name for x in imgdir.glob("*.jpg")) if imgdir.exists() else []
        price = p.get("판매가_수정") or p.get("판매가_규칙")
        p["price"] = int(str(price).replace(",", "")) if price else None
        items.append(p)
    return items

PAGE = """<!doctype html><html lang="ko"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow">
<title>{title}</title>
<style>
:root{{--bg:#faf8f5;--card:#fff;--ink:#1d1b19;--mute:#7a736b;--line:#e9e3db;--accent:#e0554a;--soft:#fff1ee}}
*{{box-sizing:border-box}}body{{margin:0;background:var(--bg);color:var(--ink);font:15px/1.5 -apple-system,"Apple SD Gothic Neo","Noto Sans KR",system-ui,sans-serif}}
header{{position:sticky;top:0;z-index:5;background:rgba(250,248,245,.94);backdrop-filter:blur(8px);border-bottom:1px solid var(--line);padding:12px 16px}}
h1{{font-size:18px;margin:0 0 8px}}h1 small{{color:var(--mute);font-weight:400;font-size:13px;margin-left:8px}}
.tools{{display:flex;gap:8px}}input[type=search]{{flex:1;padding:10px 12px;border:1px solid var(--line);border-radius:10px;font-size:15px;background:#fff}}
select{{padding:10px;border:1px solid var(--line);border-radius:10px;background:#fff;font-size:14px}}
main{{padding:12px;display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:10px}}
@media(min-width:700px){{main{{grid-template-columns:repeat(auto-fill,minmax(210px,1fr));gap:14px;padding:18px}}}}
.card{{background:var(--card);border:1px solid var(--line);border-radius:14px;overflow:hidden;cursor:pointer;position:relative}}
.card img{{width:100%;aspect-ratio:3/4;object-fit:cover;display:block;background:#eee}}
.card .b{{padding:8px 10px 10px}}.name{{font-weight:600;font-size:14px;line-height:1.3;margin-bottom:4px}}
.price{{color:var(--accent);font-weight:700}}.meta{{color:var(--mute);font-size:12px;margin-top:3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}}
.new{{position:absolute;top:8px;left:8px;background:var(--accent);color:#fff;font-size:11px;padding:2px 7px;border-radius:99px}}
.sold{{position:absolute;inset:0;background:rgba(255,255,255,.65);display:grid;place-items:center;font-weight:700;color:#444}}
.cnt{{padding:0 16px;color:var(--mute);font-size:13px}}
/* modal */
.m{{position:fixed;inset:0;background:rgba(0,0,0,.55);display:none;z-index:10;overflow:auto}}.m.on{{display:block}}
.sheet{{background:#fff;max-width:720px;margin:0 auto;min-height:100%;padding:0 0 40px}}
.sheet .top{{position:sticky;top:0;background:#fff;display:flex;justify-content:space-between;align-items:center;padding:12px 16px;border-bottom:1px solid var(--line);z-index:1}}
.sheet .top b{{font-size:16px}}.x{{border:0;background:#f1ece6;border-radius:99px;width:34px;height:34px;font-size:18px;cursor:pointer}}
.info{{padding:14px 16px;display:grid;grid-template-columns:70px 1fr;gap:6px 10px;font-size:14px}}.info dt{{color:var(--mute)}}.info dd{{margin:0}}
.info .p{{font-size:20px;font-weight:800;color:var(--accent)}}
.copy{{margin:4px 16px 14px;display:block;width:calc(100% - 32px);padding:12px;border:0;border-radius:12px;background:var(--ink);color:#fff;font-size:15px;font-weight:600;cursor:pointer}}
.note{{margin:0 16px 12px;padding:10px 12px;background:var(--soft);border-radius:10px;font-size:13px;color:#7a2e27}}
.gal img{{width:100%;display:block}}
</style></head><body>
<header><h1>{title}<small>{count}종 · {date} 업데이트</small></h1>
<div class="tools"><input type="search" id="q" placeholder="상품명 검색 (예: 레깅스, 티)"><select id="sort"><option value="new">최신순</option><option value="low">낮은 가격</option><option value="high">높은 가격</option><option value="name">이름순</option></select></div></header>
<div class="cnt" id="cnt"></div>
<main id="grid"></main>
<div class="m" id="m"><div class="sheet"><div class="top"><b id="mt"></b><button class="x" id="mx">×</button></div>
<dl class="info" id="mi"></dl><div class="note" id="mn"></div><button class="copy" id="mc">주문 문구 복사</button><div class="gal" id="mg"></div></div></div>
<script>
const P={data};const dir={dir};const ship='{ship}';
const won=n=>n.toLocaleString('ko-KR')+'원';
const grid=document.getElementById('grid'),q=document.getElementById('q'),sort=document.getElementById('sort');
function render(){{const t=q.value.trim();let a=P.filter(p=>!t||p.n.includes(t));
 if(sort.value=='low')a.sort((x,y)=>x.pr-y.pr);else if(sort.value=='high')a.sort((x,y)=>y.pr-x.pr);else if(sort.value=='name')a.sort((x,y)=>x.n.localeCompare(y.n));else a.sort((x,y)=>y.d.localeCompare(x.d));
 document.getElementById('cnt').textContent=a.length+'개 상품';
 grid.innerHTML=a.map(p=>`<div class="card" data-id="${{p.id}}">${{p.img?`<img loading="lazy" src="${{dir}}/${{p.f}}/이미지/${{p.img[0]}}">`:'<div style="aspect-ratio:3/4;background:#eee"></div>'}}${{p.new?'<span class="new">NEW</span>':''}}${{(p.s||'').trim()=='품절'?'<div class="sold">품절</div>':''}}<div class="b"><div class="name">${{p.n}}</div><div class="price">${{won(p.pr)}}${{p.xm?`~${{won(p.pr+p.xm)}}`:''}}</div><div class="meta">${{p.sz}}</div></div></div>`).join('')}}
q.oninput=render;sort.onchange=render;render();
const m=document.getElementById('m');let cur;
grid.onclick=e=>{{const c=e.target.closest('.card');if(!c)return;cur=P.find(p=>p.id==c.dataset.id);
 document.getElementById('mt').textContent=cur.n;
 document.getElementById('mi').innerHTML=`<dt>가격</dt><dd class="p">${{won(cur.pr)}}${{cur.xm?` ~ ${{won(cur.pr+cur.xm)}}`:''}}</dd><dt>색상</dt><dd>${{cur.c||'-'}}</dd><dt>사이즈</dt><dd>${{cur.sz||'-'}}</dd>${{cur.x?`<dt>추가금</dt><dd>${{cur.x}}</dd>`:''}}<dt>배송비</dt><dd>${{ship}}</dd>`;
 const sold=(cur.s||'').trim()=='품절';
 document.getElementById('mn').textContent=sold?'품절된 상품입니다':'주문은 CS채널로 보내주세요. 아래 버튼으로 문구를 복사해 색상·사이즈만 채우시면 됩니다.';
 const cb=document.getElementById('mc'); cb.disabled=sold; cb.style.opacity=sold?.45:1;
 cb.style.cursor=sold?'default':'pointer'; cb.textContent=sold?'품절':'주문 문구 복사';
 document.getElementById('mg').innerHTML=cur.img.map(i=>`<img loading="lazy" src="${{dir}}/${{cur.f}}/이미지/${{i}}">`).join('');
 m.classList.add('on');m.scrollTop=0;document.body.style.overflow='hidden'}};
document.getElementById('mx').onclick=()=>{{m.classList.remove('on');document.body.style.overflow=''}};
document.getElementById('mc').onclick=async()=>{{const t=`[주문] ${{cur.n}} / 색상: ( ) / 사이즈: ( ) / 수량: 1 — ${{won(cur.pr)}}`
  +(cur.xm?` (선택에 따라 최대 +${{cur.xm.toLocaleString('ko-KR')}}원)`:'')
  +` / 배송비 ${{ship}}`;try{{await navigator.clipboard.writeText(t);document.getElementById('mc').textContent='복사됐어요 ✓';setTimeout(()=>document.getElementById('mc').textContent='주문 문구 복사',1500)}}catch(e){{const g=document.getElementById('mn');g.innerHTML='아래 문구를 길게 눌러 복사하세요<br><textarea readonly rows="2" style="width:100%;margin-top:8px;font:inherit;padding:8px;border-radius:8px;border:1px solid #ccc">'+t+'</textarea>';}}}};
</script></body></html>"""

def write_page(items, dst: pathlib.Path, title: str, img_prefix: str = "..", cfg: dict = None):
    """상품 목록 → HTML 한 장. img_prefix 는 이미지 폴더로 가는 상대 경로."""
    dst.parent.mkdir(parents=True, exist_ok=True)
    cfg = cfg or {}
    ship = f"{int(cfg.get('배송비', 3500)):,}원"
    new_days = int(cfg.get("NEW기간_일", 7))
    today = datetime.date.today()
    def is_new(d):
        try:
            return (today - datetime.date.fromisoformat(str(d)[:10])).days <= new_days
        except Exception:
            return False
    def max_extra(v):
        import re as _re
        n = [int(x.replace(",", "")) for x in _re.findall(r"\+([\d,]+)", str(v or ""))]
        return max(n) if n else 0

    data = [{"id": p["상품ID"], "n": p["상품명"], "d": str(p.get("등록일") or ""), "pr": p["price"],
             "c": p.get("색상") or "", "sz": p.get("사이즈") or "", "x": p.get("옵션추가금") or "",
             "xm": max_extra(p.get("옵션추가금")),
             "f": p["이미지폴더"], "img": p["images"], "s": p.get("상태") or "",
             "new": is_new(p.get("등록일"))} for p in items]
    dst.write_text(PAGE.format(title=html.escape(title), count=len(items),
                               date=today.isoformat(), data=json.dumps(data, ensure_ascii=False),
                               dir=json.dumps(img_prefix), ship=ship), encoding="utf-8")
    return len(items)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("folder"); ap.add_argument("--title", default=None); ap.add_argument("--out", default=None)
    a = ap.parse_args()
    folder = pathlib.Path(a.folder)
    items = read_master(folder)
    if not items:
        raise SystemExit("⛔ " + explain_empty(folder) + "\n   이 화면을 캡처해서 강사님께 보내주세요.")
    out = pathlib.Path(a.out or folder / "catalog")
    prefix = ".." if out.parent == folder else folder.resolve().as_posix()
    try:
        import settings as st
        cfg = st.load()
    except SystemExit:
        cfg = {}
    title = a.title or f"{items[0]['브랜드']} 카탈로그"
    write_page(items, out / "index.html", title, img_prefix=prefix, cfg=cfg)
    print(f"✅ {out/'index.html'} — {len(items)}종, 이미지 있는 상품 {sum(1 for p in items if p['images'])}종")


if __name__ == "__main__":
    main()
