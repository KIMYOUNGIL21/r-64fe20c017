#!/usr/bin/env python3
"""수집기 1단계 — 키즈빌리지 브랜드 엑셀(네이버 스토어팜용) → 상품마스터 + 이미지 폴더.

키즈빌리지에는 아무것도 쓰지 않는다. 엑셀에 적힌 이미지 URL만 천천히 읽는다.

사용:
  collect.py <브랜드엑셀.xlsx> --out 수집/아오스타 [--since 2026-08-01] [--no-images] [--limit N]
"""

import sys as _sys
for _s in (_sys.stdout, _sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
import argparse, json, re, sys, time, pathlib, datetime
import openpyxl, requests

sys.path.insert(0, str(pathlib.Path(__file__).parent))
import settings as st

MARGIN = [(35000, 3500), (20000, 3000), (0, 2500)]   # 설정.txt를 못 읽을 때만 쓰는 기본값
IMG_RE = re.compile(r"https://kidsvillage\.co\.kr/data/item/([^/]+)/[^'\"\s<>]+")
PAUSE = 0.4   # 이미지 요청 사이 (초)


CFG = None


def margin(supply: int) -> int:
    if CFG:
        return st.margin(CFG, supply)
    for floor, m in MARGIN:
        if supply >= floor:
            return m
    return MARGIN[-1][1]


def load(path):
    wb = openpyxl.load_workbook(path, read_only=True)
    rows = list(wb.worksheets[0].iter_rows(values_only=True))
    hdr = rows[1]
    H = {h: i for i, h in enumerate(hdr) if h}
    need = ["상품명", "판매가", "옵션명", "옵션값", "옵션가", "대표이미지", "추가이미지", "상세설명", "브랜드", "제조일자"]
    missing = [n for n in need if n not in H]
    if missing:
        sys.exit("⛔ 엑셀 형식이 바뀌었습니다. 이 화면을 캡처해서 강사님께 보내주세요.\n"
                 f"   (없는 항목: {', '.join(missing)})\n"
                 "   오늘은 예전 방식으로 진행하시면 됩니다.")
    return rows[2:], H


def parse(row, H):
    g = lambda k: row[H[k]]
    consumer = int(str(g("판매가")).replace(",", ""))
    supply = round(consumer / 1.6)          # 900원대 가격도 버리지 않는다
    urls = []
    for k in ("대표이미지", "추가이미지", "상세설명"):
        urls += IMG_RE.findall(str(g(k) or "")) and [m.group(0) for m in IMG_RE.finditer(str(g(k) or ""))]
    seen, uniq = set(), []
    for u in urls:
        key = u.split("?")[0]
        if key not in seen:
            seen.add(key); uniq.append(u)
    m = IMG_RE.search(str(g("대표이미지") or "")) or IMG_RE.search(str(g("상세설명") or ""))
    if m:
        it_id = m.group(1)
    else:
        # 사진 주소에서 번호를 못 뽑는 브랜드가 있다. 상품명으로 대신 만든다.
        import hashlib
        it_id = "N" + hashlib.md5(str(g("상품명")).encode("utf-8")).hexdigest()[:12]
    names = str(g("옵션명") or "").split("\n")
    vals = str(g("옵션값") or "").split("\n")
    extra = str(g("옵션가") or "").split("\n")
    opts = {}
    for n, v, e in zip(names, vals, extra):
        vs = [x for x in v.split(",") if x]
        es = []
        for x in e.split(","):
            digits = re.sub(r"[^\d-]", "", x)
            es.append(int(digits) if digits.lstrip("-").isdigit() else 0)
        opts[n.strip()] = [{"값": a, "추가금": (es[i] if i < len(es) else 0)} for i, a in enumerate(vs)]
    surcharge = "; ".join(f"{o['값']} +{o['추가금']:,}" for lst in opts.values() for o in lst if o["추가금"])
    return {
        "상품ID": it_id,
        "브랜드": g("브랜드"),
        "상품명": str(g("상품명")).strip(),
        "등록일": str(g("제조일자"))[:10],
        "공급가": supply,
        "소비자가": consumer,
        "판매가_규칙": supply + margin(supply),
        "판매가_수정": None,
        "색상": " / ".join(o["값"] for o in opts.get("색상", [])),
        "사이즈": " / ".join(o["값"] for o in opts.get("사이즈", [])),
        "옵션추가금": surcharge,
        "이미지수": len(uniq),  # 엑셀에 있는 전체 수. 실제 받은 수는 폴더 기준
        "이미지URL": uniq,
        "상태": "판매중",   # 판매중 / 품절 / 숨김
    }


def as_date(v):
    """'2026-08-06', '2026.08.06', '20260806' 등을 날짜로. 못 읽으면 None."""
    t = re.sub(r"[^\d]", "", str(v or ""))[:8]
    if len(t) != 8:
        return None
    try:
        return datetime.date(int(t[:4]), int(t[4:6]), int(t[6:8]))
    except ValueError:
        return None


def safe(name):
    return re.sub(r"[^\w가-힣]+", "_", name).strip("_")[:40]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("xlsx"); ap.add_argument("--out", required=True)
    ap.add_argument("--since", default=None, help="이 등록일 이후만 (YYYY-MM-DD). 기본: 최근 30일")
    ap.add_argument("--limit", type=int); ap.add_argument("--no-images", action="store_true")
    ap.add_argument("--max-images", type=int, default=None, help="상품당 받을 이미지 수 (기본: 설정.txt의 이미지수)")
    a = ap.parse_args()
    global CFG
    try:
        CFG = st.load()
        if a.max_images is None:
            a.max_images = int(CFG["이미지수"])
    except SystemExit:
        CFG = None
    if a.max_images is None:
        a.max_images = 20
    out = pathlib.Path(a.out); out.mkdir(parents=True, exist_ok=True)
    if not a.since:
        a.since = str(datetime.date.today() - datetime.timedelta(days=30))
        print(f"   (날짜를 안 정하셔서 최근 30일 = {a.since} 이후로 합니다)")
    rows, H = load(a.xlsx)
    since_date = as_date(a.since)
    if since_date is None:
        sys.exit(f"⛔ 날짜 '{a.since}' 를 알아볼 수 없습니다. 2026-08-01 처럼 적어 주세요.")
    items, errors, undated = [], [], 0
    for r in rows:
        try:
            p = parse(r, H)
        except Exception as e:
            errors.append(f"{r[H['상품명']]}: {e}"); continue
        if a.since:
            d = as_date(p["등록일"])
            if d is None:
                undated += 1
                continue
            if d < since_date:
                continue
        items.append(p)
    if a.limit: items = items[: a.limit]
    print(f"엑셀 {len(rows)}행 → 대상 {len(items)}종, 파싱 실패 {len(errors)}")
    if not items:
        sys.exit(f"⛔ 올릴 상품이 0종입니다. 날짜({a.since})를 더 앞으로 잡아 주세요.\n"
                 "   (엑셀에 있는 가장 최근 등록일보다 뒤로 잡으면 아무것도 걸리지 않습니다)")
    master = out / "상품마스터.xlsx"
    brand_now = str(items[0].get("브랜드") or "").strip()
    if master.exists():
        try:
            _ws = openpyxl.load_workbook(master, read_only=True).active
            _rows = list(_ws.iter_rows(values_only=True))
            _h = {h: i for i, h in enumerate(_rows[0]) if h}
            olds = {str(r[_h["브랜드"]]).strip() for r in _rows[1:] if r[_h.get("브랜드", -1)]}
            if olds and brand_now and brand_now not in olds:
                sys.exit(f"⛔ 이 폴더에는 '{', '.join(sorted(olds))}' 자료가 들어 있는데,\n"
                         f"   받으신 엑셀은 '{brand_now}' 입니다.\n"
                         f"   브랜드를 잘못 말씀하셨거나 엑셀을 잘못 받으신 것 같습니다.\n"
                         f"   맞다면 '{brand_now}' 로 다시 말씀해 주세요.")
        except SystemExit:
            raise
        except Exception:
            pass


    for e in errors[:5]: print("  ⚠ 건너뜀:", e)
    if len(errors) > 5:
        print(f"  ⚠ … 외 {len(errors) - 5}종 더")
    subbed = sum(1 for p in items if str(p["상품ID"]).startswith("N"))
    if subbed:
        print(f"   (사진 주소에 번호가 없는 상품 {subbed}종은 이름으로 번호를 붙였습니다)")
    if undated:
        print(f"  ⚠ 등록일을 알 수 없는 상품 {undated}종은 제외했습니다.")
    if errors:
        print(f"  ⚠ 모두 {len(errors)}종을 건너뛰었습니다. 예상보다 적으면 이 화면을 캡처해 강사님께 보내주세요.")

    s = requests.Session(); s.headers["User-Agent"] = "Mozilla/5.0 (kidsvillage seller tool; slow read-only)"
    miss_row = miss_streak = 0
    if not a.no_images:
        print(f"   사진을 받습니다. {len(items)}종이면 {max(1, len(items) // 6)}분쯤 걸립니다. 창을 닫지 마세요.")
    total_img = 0
    for i, p in enumerate(items, 1):
        folder = out / f"{p['상품ID']}_{safe(p['상품명'])}"
        p["이미지폴더"] = folder.name
        if not a.no_images:
            (folder / "이미지").mkdir(parents=True, exist_ok=True)
            for n, u in enumerate(p["이미지URL"][: a.max_images], 1):
                dst = folder / "이미지" / f"{n:02d}.jpg"
                if dst.exists() and dst.stat().st_size > 0:
                    continue
                r = None
                for attempt in (1, 2, 3):
                    try:
                        r = s.get(u, timeout=30)
                        if r.status_code == 200 and r.headers.get("content-type", "").startswith("image"):
                            break
                    except requests.RequestException:
                        r = None
                    if attempt < 3:
                        time.sleep(2 * attempt)
                if r is None or r.status_code != 200 or not r.headers.get("content-type", "").startswith("image"):
                    miss_row += 1
                    miss_streak += 1
                    if miss_streak >= 5:
                        sys.exit("⛔ 사진을 연달아 받지 못해 멈췄습니다.\n"
                                 "   엑셀을 키즈빌리지에서 새로 받아 다시 해 보세요.\n"
                                 "   그래도 안 되면 이 화면을 캡처해서 강사님께 보내주세요.")
                    continue
                miss_streak = 0
                dst.write_bytes(r.content); total_img += 1
                time.sleep(PAUSE)
            got = len(list((folder / "이미지").glob("*.jpg")))
            print(f"[{i}/{len(items)}] {p['상품명']} — 이미지 {got}장" + ("  (일부 못 받음)" if got < min(p["이미지수"], a.max_images) else ""))
        folder.mkdir(parents=True, exist_ok=True)
        (folder / "정보.json").write_text(json.dumps({k: v for k, v in p.items() if k != "이미지URL"}, ensure_ascii=False, indent=2), encoding="utf-8")

    # 지난번 자료와 합친다 — 어제 올린 상품과 손으로 고친 값이 사라지지 않게
    kept = {}
    prev_rows = []
    if master.exists():
        try:
            old = openpyxl.load_workbook(master, read_only=True).active
            orows = list(old.iter_rows(values_only=True))
            oh = {h: i for i, h in enumerate(orows[0]) if h}
            for r in orows[1:]:
                pid = r[oh["상품ID"]]
                if not pid:
                    continue
                rec = {c: r[oh[c]] for c in oh}
                prev_rows.append(rec)
                fix, state = rec.get("판매가_수정"), rec.get("상태")
                if fix or (state and str(state).strip() not in ("", "판매중")):
                    kept[str(pid)] = (fix, state)
        except Exception:
            kept, prev_rows = {}, []
    for p in items:
        if str(p["상품ID"]) in kept:
            fix, state = kept[str(p["상품ID"])]
            if fix:
                p["판매가_수정"] = fix
            if state:
                p["상태"] = str(state).strip()
    if kept:
        print(f"   (지난번에 고치신 가격·품절 표시 {len(kept)}건을 그대로 두었습니다)")

    # 이번 엑셀에 없던 지난 상품도 그대로 남긴다 (어제 올린 것이 사라지지 않게)
    now_ids = {str(p["상품ID"]) for p in items}
    carried = [r for r in prev_rows if str(r.get("상품ID")) not in now_ids]
    if carried:
        print(f"   (지난번에 올리신 {len(carried)}종도 페이지에 그대로 둡니다)")

    # 상품마스터 엑셀
    wb = openpyxl.Workbook(); ws = wb.active; ws.title = "상품마스터"
    cols = ["상품ID", "브랜드", "상품명", "등록일", "공급가", "소비자가", "판매가_규칙", "판매가_수정", "색상", "사이즈", "옵션추가금", "이미지수", "이미지폴더", "상태"]
    ws.append(cols)
    for p in items: ws.append([p.get(c) for c in cols])
    for r in carried: ws.append([r.get(c) for c in cols])
    for c, w in zip("ABCDEFGHIJKLMN", [16, 10, 28, 12, 9, 9, 11, 11, 40, 22, 24, 8, 40, 8]):
        ws.column_dimensions[c].width = w
    master = out / "상품마스터.xlsx"
    try:
        wb.save(master)
    except PermissionError:
        sys.exit("⛔ 상품마스터.xlsx 가 열려 있어 저장하지 못했습니다.\n"
                 "   엑셀을 닫고 다시 해 주세요. 사진은 이미 받아 뒀으니 이번엔 금방 끝납니다.")
    (out / "상품마스터.json").write_text(json.dumps([{k: v for k, v in p.items() if k != "이미지URL"} for p in items], ensure_ascii=False, indent=1), encoding="utf-8")
    if miss_row:
        print(f"  ⚠ 사진 {miss_row}장은 받지 못했습니다 (그 상품도 나머지 사진으로 올라갑니다).")
    print(f"✅ 상품마스터 {master} ({len(items) + len(carried)}종) · 이미지 {total_img}장 새로 받음 · {datetime.datetime.now():%H:%M}")


if __name__ == "__main__":
    main()
