#!/usr/bin/env python3
"""상품마스터 고치기 — 가격 수정·품절·숨김.

  edit_master.py 수집/아오스타 --상품 "에브리레깅스" --판매가 9000
  edit_master.py 수집/아오스타 --상품 "초코칩머플러" --상태 품절
  edit_master.py 수집/아오스타 --상품 "쿠키티" --상태 숨김
  edit_master.py 수집/아오스타 --상품 "에브리레깅스" --판매가 없음     (규칙 가격으로 되돌리기)

상품 이름은 일부만 적어도 됩니다. 여러 개가 걸리면 무엇이 걸렸는지 보여주고 멈춥니다.
"""

import sys as _sys
for _s in (_sys.stdout, _sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
import argparse, pathlib, sys
import openpyxl

STATES = ("판매중", "품절", "숨김")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("folder")
    ap.add_argument("--상품", required=True, dest="name")
    ap.add_argument("--판매가", dest="price", default=None)
    ap.add_argument("--상태", dest="state", default=None, choices=STATES)
    a = ap.parse_args()

    if a.price is None and a.state is None:
        sys.exit("⛔ 무엇을 바꿀지 알려주세요 (--판매가 또는 --상태)")

    f = pathlib.Path(a.folder) / "상품마스터.xlsx"
    if not f.exists():
        sys.exit(f"⛔ {f} 가 없습니다.")
    try:
        wb = openpyxl.load_workbook(f)
    except PermissionError:
        sys.exit("⛔ 상품마스터.xlsx 가 열려 있습니다. 엑셀을 닫고 다시 해 주세요.")
    ws = wb.active
    hdr = [c.value for c in ws[1]]
    col = {h: i + 1 for i, h in enumerate(hdr) if h}

    hits = [r for r in range(2, ws.max_row + 1)
            if a.name in str(ws.cell(r, col["상품명"]).value or "")]
    if not hits:
        sys.exit(f"⛔ '{a.name}' 이라는 상품을 찾지 못했습니다.")
    if len(hits) > 1:
        names = ", ".join(str(ws.cell(r, col["상품명"]).value) for r in hits[:8])
        sys.exit(f"⛔ '{a.name}' 에 해당하는 상품이 {len(hits)}개입니다: {names}\n"
                 "   이름을 더 정확히 알려주세요.")

    r = hits[0]
    name = ws.cell(r, col["상품명"]).value
    before_price = ws.cell(r, col["판매가_수정"]).value or ws.cell(r, col["판매가_규칙"]).value
    before_state = ws.cell(r, col["상태"]).value
    said = []

    if a.price is not None:
        if a.price in ("없음", "지움", "-"):
            ws.cell(r, col["판매가_수정"]).value = None
            said.append(f"가격 {int(before_price):,}원 → 규칙 가격 {int(ws.cell(r, col['판매가_규칙']).value):,}원")
        else:
            new = int(str(a.price).replace(",", "").replace("원", "").strip())
            ws.cell(r, col["판매가_수정"]).value = new
            said.append(f"가격 {int(before_price):,}원 → {new:,}원")
    if a.state is not None:
        ws.cell(r, col["상태"]).value = a.state
        said.append(f"상태 {before_state} → {a.state}")

    wb.save(f)
    print(f"✅ {name} — " + " · ".join(said))
    print("   이제 다시 올리면 페이지에 반영됩니다.")


if __name__ == "__main__":
    main()
