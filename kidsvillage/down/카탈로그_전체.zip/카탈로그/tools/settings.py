#!/usr/bin/env python3
"""설정.txt 읽기 — 모든 도구가 여기를 통해 판매자님 값을 읽는다.

`설정.txt`는 판매자님이 직접 고치는 파일이라, 형식이 조금 틀려도 최대한 읽어 준다.
값이 없거나 이상하면 기본값을 쓰되, **비밀번호처럼 빠지면 안 되는 값은 예외를 던진다.**
"""

import sys as _sys
for _s in (_sys.stdout, _sys.stderr):
    try:
        _s.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
import pathlib, re, sys

DEFAULTS = {
    "페이지이름": "catalog",
    "비밀번호": "",
    "마진_35000이상": 3500,
    "마진_20000이상": 3000,
    "마진_그외": 2500,
    "배송비": 3500,
    "이미지수": 20,
    "NEW기간_일": 7,
    "방이름": "공동구매",
    "시즌": "신상",
    "보관브랜드수": 8,
}
INT_KEYS = {"마진_35000이상", "마진_20000이상", "마진_그외", "배송비", "이미지수", "NEW기간_일", "보관브랜드수"}


def find(start: pathlib.Path = None) -> pathlib.Path:
    """설정.txt 를 위로 거슬러 올라가며 찾는다."""
    p = (start or pathlib.Path.cwd()).resolve()
    for d in [p, *p.parents]:
        f = d / "설정.txt"
        if f.exists():
            return f
    raise SystemExit("⛔ 설정.txt 를 찾지 못했습니다. 카탈로그 폴더 안에서 실행해 주세요.")


def load(path: pathlib.Path = None) -> dict:
    f = path or find()
    cfg = dict(DEFAULTS)
    try:
        raw = f.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        raw = f.read_text(encoding="cp949")     # 메모장에서 ANSI 로 저장한 경우
    for line in raw.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        k, v = k.strip(), v.split("#")[0].strip()
        if k not in DEFAULTS:
            continue
        if k in INT_KEYS:
            digits = re.sub(r"[^\d]", "", v)
            if digits:
                cfg[k] = int(digits)
        else:
            cfg[k] = v
    cfg["_path"] = f

    if not cfg["비밀번호"] or cfg["비밀번호"] == "바꿔주세요":
        raise SystemExit(f"⛔ {f} 의 비밀번호가 아직 비어 있습니다.\n"
                         "   코덱스에게 \"설정 파일 같이 채우자\" 라고 하시면 함께 채웁니다.")
    if not cfg["비밀번호"].isascii():
        print("   ⚠ 비밀번호에 한글이 들어 있습니다. 영문·숫자로 바꾸시는 것을 권합니다.")
    if not re.fullmatch(r"[a-z0-9][a-z0-9-]{1,40}", cfg["페이지이름"]):
        raise SystemExit(f"⛔ 페이지이름 '{cfg['페이지이름']}' 은 쓸 수 없습니다.\n"
                         "   영문 소문자·숫자·하이픈만, 2글자 이상으로 정해 주세요 (예: sodam).")
    return cfg


def margin(cfg: dict, supply: int) -> int:
    if supply >= 35000:
        return cfg["마진_35000이상"]
    if supply >= 20000:
        return cfg["마진_20000이상"]
    return cfg["마진_그외"]


if __name__ == "__main__":
    c = load(pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else None)
    print(f"설정 파일: {c.pop('_path')}")
    for k, v in c.items():
        print(f"  {k} = {'*' * len(v) if k == '비밀번호' else v}")
