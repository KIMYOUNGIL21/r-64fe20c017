# -*- coding: utf-8 -*-
"""
시황 키트 — 오늘의 시황을 내 텔레그램으로 보내는 프로그램
그밤PD 챌린지 1기 · 1주차 배포 재료 (v1.0)

이 파일은 고치지 않아도 됩니다. 고칠 것은 '설정.txt' 하나뿐입니다.
실행:  python 시황.py            → 시황을 텔레그램으로 보냄
       python 시황.py --미리보기  → 보내지 않고 화면에만 출력 (열쇠 없어도 됨)

만든 사람: 그밤PD · 설치할 것 없음(파이썬 기본 기능만 사용)
"""

import sys
import os
import json
import time
import urllib.request
import urllib.parse
import urllib.error
from datetime import datetime, timezone, timedelta

# 윈도우 검은 창(cmd)에서 한글이 깨지지 않게 하는 안전장치
try:
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
except Exception:
    pass

여기 = os.path.dirname(os.path.abspath(__file__))
설정파일 = os.path.join(여기, "설정.txt")
한국시간 = timezone(timedelta(hours=9))
브라우저인척 = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
              "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36")

# 값을 안 채웠을 때 흔히 남아있는 글자들 — 이게 들어있으면 "비어있다"로 봅니다
빈값들 = {"", "xxxx", "xxx", "여기에붙여넣기", "여기에", "내토큰", "토큰", "챗id", "chat_id",
        "your_token", "your_chat_id", "0"}


# ────────────────────────────────────────────────────────────
# 1. 내가 볼 수 있는 국내 종목 이름표 (실측 검증된 118종목)
#    여기 없는 종목은 6자리 숫자 코드로 적으면 됩니다.
# ────────────────────────────────────────────────────────────
종목표 = {
    "하이트진로": ("000080", "KS"),
    "유한양행": ("000100", "KS"),
    "두산": ("000150", "KS"),
    "삼천당제약": ("000250", "KQ"),
    "기아": ("000270", "KS"),
    "SK하이닉스": ("000660", "KS"),
    "현대건설": ("000720", "KS"),
    "삼성화재": ("000810", "KS"),
    "한화": ("000880", "KS"),
    "CJ": ("001040", "KS"),
    "대한항공": ("003490", "KS"),
    "LG": ("003550", "KS"),
    "포스코퓨처엠": ("003670", "KS"),
    "신세계": ("004170", "KS"),
    "농심": ("004370", "KS"),
    "빙그레": ("005180", "KS"),
    "현대차": ("005380", "KS"),
    "POSCO홀딩스": ("005490", "KS"),
    "삼립": ("005610", "KS"),
    "삼성전자": ("005930", "KS"),
    "녹십자": ("006280", "KS"),
    "GS건설": ("006360", "KS"),
    "삼성SDI": ("006400", "KS"),
    "미래에셋증권": ("006800", "KS"),
    "GS리테일": ("007070", "KS"),
    "오뚜기": ("007310", "KS"),
    "이수페타시스": ("007660", "KS"),
    "호텔신라": ("008770", "KS"),
    "삼성전기": ("009150", "KS"),
    "한화솔루션": ("009830", "KS"),
    "OCI홀딩스": ("010060", "KS"),
    "LS ELECTRIC": ("010120", "KS"),
    "고려아연": ("010130", "KS"),
    "S-Oil": ("010950", "KS"),
    "롯데케미칼": ("011170", "KS"),
    "HMM": ("011200", "KS"),
    "금호석유화학": ("011780", "KS"),
    "현대모비스": ("012330", "KS"),
    "한화에어로스페이스": ("012450", "KS"),
    "한국전력": ("015760", "KS"),
    "삼성증권": ("016360", "KS"),
    "SK텔레콤": ("017670", "KS"),
    "삼성에스디에스": ("018260", "KS"),
    "롯데쇼핑": ("023530", "KS"),
    "삼성물산": ("028260", "KS"),
    "HLB": ("028300", "KQ"),
    "제일기획": ("030000", "KS"),
    "KT": ("030200", "KS"),
    "LG유플러스": ("032640", "KS"),
    "삼성생명": ("032830", "KS"),
    "KT&G": ("033780", "KS"),
    "두산에너빌리티": ("034020", "KS"),
    "파라다이스": ("034230", "KS"),
    "SK": ("034730", "KS"),
    "강원랜드": ("035250", "KS"),
    "NAVER": ("035420", "KS"),
    "카카오": ("035720", "KS"),
    "CJ ENM": ("035760", "KQ"),
    "JYP Ent.": ("035900", "KQ"),
    "콘텐트리중앙": ("036420", "KS"),
    "NC": ("036570", "KS"),
    "키움증권": ("039490", "KS"),
    "에스엠": ("041510", "KQ"),
    "한미반도체": ("042700", "KS"),
    "대우건설": ("047040", "KS"),
    "한국항공우주": ("047810", "KS"),
    "LG생활건강": ("051900", "KS"),
    "LG화학": ("051910", "KS"),
    "한전기술": ("052690", "KS"),
    "신한지주": ("055550", "KS"),
    "리노공업": ("058470", "KQ"),
    "현대로템": ("064350", "KS"),
    "LG전자": ("066570", "KS"),
    "셀트리온": ("068270", "KS"),
    "셀트리온제약": ("068760", "KQ"),
    "대웅제약": ("069620", "KS"),
    "컴투스": ("078340", "KQ"),
    "GS": ("078930", "KS"),
    "LIG디펜스앤에어로스페이스": ("079550", "KS"),
    "현대글로비스": ("086280", "KS"),
    "에코프로": ("086520", "KQ"),
    "하나금융지주": ("086790", "KS"),
    "아모레퍼시픽": ("090430", "KS"),
    "씨젠": ("096530", "KQ"),
    "SK이노베이션": ("096770", "KS"),
    "CJ제일제당": ("097950", "KS"),
    "풍산": ("103140", "KS"),
    "KB금융": ("105560", "KS"),
    "위메이드": ("112040", "KQ"),
    "씨에스윈드": ("112610", "KS"),
    "한미약품": ("128940", "KS"),
    "이마트": ("139480", "KS"),
    "휴젤": ("145020", "KQ"),
    "덴티움": ("145720", "KS"),
    "알테오젠": ("196170", "KQ"),
    "HL만도": ("204320", "KS"),
    "삼성바이오로직스": ("207940", "KS"),
    "클래시스": ("214150", "KQ"),
    "파마리서치": ("214450", "KQ"),
    "두산밥캣": ("241560", "KS"),
    "에코프로비엠": ("247540", "KQ"),
    "넷마블": ("251270", "KS"),
    "스튜디오드래곤": ("253450", "KQ"),
    "실리콘투": ("257720", "KQ"),
    "크래프톤": ("259960", "KS"),
    "펄어비스": ("263750", "KQ"),
    "오리온": ("271560", "KS"),
    "레인보우로보틱스": ("277810", "KQ"),
    "롯데웰푸드": ("280360", "KS"),
    "BGF리테일": ("282330", "KS"),
    "효성중공업": ("298040", "KS"),
    "우리금융지주": ("316140", "KS"),
    "카카오뱅크": ("323410", "KS"),
    "HD현대중공업": ("329180", "KS"),
    "하이브": ("352820", "KS"),
    "LG에너지솔루션": ("373220", "KS"),
    "카카오페이": ("377300", "KS"),
    "SK스퀘어": ("402340", "KS"),
}

# 사람들이 흔히 부르는 다른 이름 → 위 표의 정식 이름
별칭 = {
    "네이버": "NAVER", "삼전": "삼성전자", "하이닉스": "SK하이닉스",
    "엔씨소프트": "NC", "엔씨": "NC", "금호석유": "금호석유화학",
    "LIG넥스원": "LIG디펜스앤에어로스페이스", "SPC삼립": "삼립",
    "포스코": "POSCO홀딩스", "포스코홀딩스": "POSCO홀딩스",
    "LG엔솔": "LG에너지솔루션", "엘지에너지솔루션": "LG에너지솔루션",
    "현대자동차": "현대차", "삼바": "삼성바이오로직스",
    "삼성SDS": "삼성에스디에스", "에코프로BM": "에코프로비엠",
    "JYP": "JYP Ent.", "SM": "에스엠", "에스오일": "S-Oil",
    "케이티앤지": "KT&G", "KT앤지": "KT&G", "엘지화학": "LG화학",
    "엘지전자": "LG전자", "두산로보틱스": "두산에너빌리티",
}


def 이름정리(s):
    """'삼성 전자' 'samsung' 같은 입력을 표와 맞춰보기 좋게 다듬습니다."""
    return s.replace(" ", "").replace(".", "").replace("-", "").upper()


_찾기표 = {이름정리(k): k for k in 종목표}
_찾기표.update({이름정리(k): v for k, v in 별칭.items()})

# 코드로 적어도 회사 이름이 나오게 (000660 → SK하이닉스)
_코드표 = {코드: (이름, 시장) for 이름, (코드, 시장) in 종목표.items()}


# ────────────────────────────────────────────────────────────
# 2. 설정 읽기 — 깃허브 액션에서는 금고(Secrets)가, 내 컴퓨터에서는 설정.txt가 쓰입니다
# ────────────────────────────────────────────────────────────
def 설정읽기():
    값 = {}
    if os.path.exists(설정파일):
        with open(설정파일, "r", encoding="utf-8") as f:
            for 줄 in f:
                줄 = 줄.strip()
                if not 줄 or 줄.startswith("#") or "=" not in 줄:
                    continue
                키, _, 밸류 = 줄.partition("=")
                값[키.strip()] = 밸류.strip().strip('"').strip("'")

    def 고르기(파일키, 환경키, 기본=""):
        # 깃허브 액션(금고)이 항상 우선입니다
        v = os.environ.get(환경키, "")
        if not v.strip():
            v = 값.get(파일키, 기본)
        return v.strip()

    토큰 = 고르기("봇토큰", "BOT_TOKEN")
    챗아이디 = 고르기("챗ID", "CHAT_ID")
    관심 = 고르기("관심종목", "WATCH")
    제목 = 고르기("제목", "TITLE", "오늘의 시황")

    if 토큰.lower() in 빈값들:
        토큰 = ""
    if 챗아이디.lower() in 빈값들:
        챗아이디 = ""
    return 토큰, 챗아이디, 관심, (제목 or "오늘의 시황")


# ────────────────────────────────────────────────────────────
# 3. 인터넷에서 값 가져오기 (여러 번 시도하고, 실패해도 프로그램은 안 죽습니다)
# ────────────────────────────────────────────────────────────
def 받아오기(url, headers=None, 시도=3, 대기=1.5):
    마지막오류 = None
    머리 = {"User-Agent": 브라우저인척, "Accept": "*/*",
          "Accept-Language": "ko-KR,ko;q=0.9,en;q=0.8"}
    if headers:
        머리.update(headers)
    for 회차 in range(시도):
        try:
            req = urllib.request.Request(url, headers=머리)
            with urllib.request.urlopen(req, timeout=15) as r:
                return r.read().decode("utf-8", "replace")
        except Exception as e:
            마지막오류 = e
            if 회차 < 시도 - 1:
                time.sleep(대기 * (회차 + 1))
    raise 마지막오류


def 야후(심볼, 이름도=False):
    """야후 파이낸스. 지수·환율·코인·국내주식을 한 곳에서 가져옵니다."""
    url = ("https://query1.finance.yahoo.com/v8/finance/chart/"
           + urllib.parse.quote(심볼) + "?range=10d&interval=1d")
    try:
        본문 = 받아오기(url)
    except Exception:
        # 첫 번째 주소가 막히면 두 번째 주소로 (액션에서 가끔 필요합니다)
        url2 = url.replace("query1.", "query2.")
        본문 = 받아오기(url2)

    결과 = json.loads(본문)["chart"]["result"][0]
    메타 = 결과.get("meta", {})
    지금 = 메타.get("regularMarketPrice")

    종가들 = []
    try:
        종가들 = [c for c in (결과["indicators"]["quote"][0]["close"] or []) if c is not None]
    except Exception:
        종가들 = []

    if 지금 is None and 종가들:
        지금 = 종가들[-1]

    # ⚠️ 함정 주의: meta 의 chartPreviousClose 는 '10일 전' 종가입니다.
    #    그걸 쓰면 코스피 등락률이 -16% 처럼 엉뚱하게 나옵니다.
    #    그래서 일별 종가 목록에서 '어제 종가'를 직접 골라냅니다.
    전일 = None
    if len(종가들) >= 2:
        마지막 = 종가들[-1]
        오늘것 = (지금 is not None and abs(마지막 - 지금) <= max(abs(지금) * 0.0001, 1e-9))
        전일 = 종가들[-2] if 오늘것 else 마지막
    elif 종가들:
        전일 = 메타.get("chartPreviousClose")

    if 지금 is None or not 전일:
        raise ValueError("값이 비어 있음")
    if 이름도:
        return float(지금), float(전일), (메타.get("shortName") or "").strip()
    return float(지금), float(전일)


def 네이버지수(코드):
    """야후가 막혔을 때 쓰는 예비 소스 (코스피/코스닥)."""
    본문 = 받아오기("https://polling.finance.naver.com/api/realtime/domestic/index/" + 코드,
                {"Referer": "https://finance.naver.com/"})
    d = json.loads(본문)["datas"][0]
    지금 = float(str(d["closePrice"]).replace(",", ""))
    율 = float(str(d["fluctuationsRatio"]).replace(",", ""))
    return 지금, 율


def 네이버종목(코드):
    """야후가 막혔을 때 쓰는 예비 소스 (국내 개별 종목)."""
    본문 = 받아오기("https://polling.finance.naver.com/api/realtime/domestic/stock/" + 코드,
                {"Referer": "https://finance.naver.com/"})
    d = json.loads(본문)["datas"][0]
    지금 = float(str(d["closePrice"]).replace(",", ""))
    율 = float(str(d["fluctuationsRatio"]).replace(",", ""))
    return 지금, 율, d.get("stockName") or 코드


def 프랑크푸르터():
    """환율 예비 소스 (유럽중앙은행 공개자료)."""
    본문 = 받아오기("https://api.frankfurter.app/2000-01-01..?from=USD&to=KRW")
    표 = json.loads(본문)["rates"]
    날짜들 = sorted(표)[-2:]
    if len(날짜들) < 2:
        raise ValueError("환율 자료 부족")
    전일 = 표[날짜들[0]]["KRW"]
    지금 = 표[날짜들[1]]["KRW"]
    return float(지금), (지금 - 전일) / 전일 * 100


def 업비트():
    """비트코인 예비 소스."""
    본문 = 받아오기("https://api.upbit.com/v1/ticker?markets=KRW-BTC")
    d = json.loads(본문)[0]
    return float(d["trade_price"]), float(d["signed_change_rate"]) * 100


# ────────────────────────────────────────────────────────────
# 4. 한 항목씩 값 구하기 (주 소스 → 실패하면 예비 소스 → 그래도 안 되면 '못 가져옴')
# ────────────────────────────────────────────────────────────
def 조회(이름, 야후심볼, 예비=None):
    """돌려주는 값: (이름, 현재가, 등락률, 어디서가져왔나)  ·  실패하면 등락률이 None"""
    try:
        지금, 전일 = 야후(야후심볼)
        return 이름, 지금, (지금 - 전일) / 전일 * 100, "야후"
    except Exception:
        pass
    if 예비:
        try:
            지금, 율 = 예비()
            return 이름, 지금, 율, "예비"
        except Exception:
            pass
    return 이름, None, None, "실패"


def 관심종목찾기(입력):
    """'삼성전자, 000660' 같은 문장을 (이름, 야후심볼, 종목코드) 목록으로 바꿉니다."""
    찾음, 못찾음, 이미본코드 = [], [], set()

    def 담기(이름, 심볼, 코드):
        # '삼성전자' 와 '005930' 을 둘 다 적어도 한 번만 나오게 합니다
        if 코드 in 이미본코드:
            return
        이미본코드.add(코드)
        찾음.append((이름, 심볼, 코드))

    for 조각 in 입력.replace("\n", ",").split(","):
        조각 = 조각.strip()
        if not 조각:
            continue
        if 조각.isdigit() and len(조각) == 6:
            # 숫자 6자리 = 종목코드
            아는것 = _코드표.get(조각)
            if 아는것:                       # 이름표에 있는 코드면 회사 이름으로 바꿔줍니다
                이름, 시장 = 아는것
                담기(이름, f"{조각}.{시장}", 조각)
            else:                           # 모르는 코드면 코스피/코스닥 중 되는 쪽을 찾습니다
                담기(조각, None, 조각)
            continue
        정식 = _찾기표.get(이름정리(조각))
        if 정식:
            코드, 시장 = 종목표[정식]
            담기(정식, f"{코드}.{시장}", 코드)
        elif 조각 not in 못찾음:
            못찾음.append(조각)
    return 찾음[:8], 못찾음      # 메시지가 너무 길어지지 않게 8개까지


def 이름정제(s):
    """야후가 이름 대신 '034950.KS,0P0000C3FZ,1206' 같은 걸 줄 때가 있어 걸러냅니다."""
    s = (s or "").strip()
    if not s or "," in s or len(s) > 30:
        return ""
    if s.replace(".", "").replace("-", "").isdigit():
        return ""
    return s


def 종목조회(이름, 야후심볼, 코드):
    if 야후심볼:
        try:
            지금, 전일 = 야후(야후심볼)
            return 이름, 지금, (지금 - 전일) / 전일 * 100
        except Exception:
            pass
    else:
        # 이름표에 없는 코드: 코스피(.KS) 먼저, 안 되면 코스닥(.KQ)
        for 꼬리 in (".KS", ".KQ"):
            try:
                지금, 전일, 야후이름 = 야후(코드 + 꼬리, 이름도=True)
                율 = (지금 - 전일) / 전일 * 100
                보일이름 = 이름정제(야후이름)
                try:                      # 한글 회사 이름을 얻을 수 있으면 그게 제일 좋습니다
                    _, _, 한글이름 = 네이버종목(코드)
                    보일이름 = 한글이름 or 보일이름
                except Exception:
                    pass
                return (보일이름 or 이름), 지금, 율
            except Exception:
                continue
    try:
        지금, 율, 실제이름 = 네이버종목(코드)
        return 실제이름, 지금, 율
    except Exception:
        return 이름, None, None


# ────────────────────────────────────────────────────────────
# 5. 보기 좋은 메시지로 조립하기
# ────────────────────────────────────────────────────────────
def 숫자(v, 소수=2):
    if v is None:
        return "—"
    return f"{v:,.{소수}f}" if 소수 else f"{v:,.0f}"


def 화살표(율):
    if 율 is None:
        return ""
    if 율 > 0.005:
        return "🔺"
    if 율 < -0.005:
        return "🔻"
    return "➖"


def 한줄(이름, 값, 율, 소수=2, 꼬리=""):
    if 값 is None or 율 is None:
        return f"{이름} —  <i>못 가져옴</i>"
    return f"{이름} {숫자(값, 소수)}{꼬리}  {화살표(율)} {abs(율):.2f}%"


def 이스케이프(s):
    """KT&G 처럼 &, <, > 가 들어간 이름 때문에 메시지가 깨지지 않게."""
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def 메시지만들기(제목, 관심입력, 조용히=False):
    def 말(s):
        if not 조용히:
            print(s)

    지금시각 = datetime.now(한국시간)
    요일 = "월화수목금토일"[지금시각.weekday()]
    오전오후 = "오전" if 지금시각.hour < 12 else "오후"
    시 = 지금시각.hour if 1 <= 지금시각.hour <= 12 else abs(지금시각.hour - 12) or 12

    말("\n[1/3] 시세를 가져옵니다…")
    항목들 = [
        조회("코스피", "^KS11", lambda: 네이버지수("KOSPI")),
        조회("코스닥", "^KQ11", lambda: 네이버지수("KOSDAQ")),
        조회("원/달러", "KRW=X", 프랑크푸르터),
        조회("S&P500", "^GSPC"),
        조회("나스닥", "^IXIC"),
        조회("비트코인", "BTC-KRW", 업비트),
    ]
    for 이름, 값, 율, 출처 in 항목들:
        말(f"    {'✔' if 율 is not None else '✖'} {이름}"
           + (f"  {숫자(값)} ({율:+.2f}%)" if 율 is not None else "  ← 못 가져옴"))

    관심결과, 못찾음 = [], []
    if 관심입력.strip():
        말("\n[2/3] 관심종목을 가져옵니다…")
        목록, 못찾음 = 관심종목찾기(관심입력)
        for 이름, 심볼, 코드 in 목록:
            r = 종목조회(이름, 심볼, 코드)
            관심결과.append(r)
            말(f"    {'✔' if r[2] is not None else '✖'} {r[0]}"
               + (f"  {숫자(r[1], 0)}원 ({r[2]:+.2f}%)" if r[2] is not None else "  ← 못 가져옴"))
        for x in 못찾음:
            말(f"    ✖ '{x}' 은(는) 이름표에 없습니다 → 종목코드 6자리로 적어주세요")
    else:
        말("\n[2/3] 관심종목은 비어 있습니다 (설정.txt 에서 추가할 수 있어요)")

    ㄱ = {이름: (값, 율) for 이름, 값, 율, _ in 항목들}
    줄들 = [f"<b>📊 {이스케이프(제목)}</b>",
          f"{지금시각.month}월 {지금시각.day}일 ({요일}) {오전오후} {시}시 {지금시각.minute:02d}분 기준",
          "",
          "🇰🇷 <b>국내</b>",
          한줄("코스피", *ㄱ["코스피"]),
          한줄("코스닥", *ㄱ["코스닥"]),
          "",
          "🌏 <b>해외 · 환율 · 코인</b>",
          한줄("S&amp;P500", *ㄱ["S&P500"]),
          한줄("나스닥", *ㄱ["나스닥"]),
          한줄("원/달러", *ㄱ["원/달러"], 꼬리="원"),
          ]

    비값, 비율 = ㄱ["비트코인"]
    if 비값 is not None:
        줄들.append(f"비트코인 {숫자(비값 / 10000, 0)}만원  {화살표(비율)} {abs(비율):.2f}%")
    else:
        줄들.append("비트코인 —  <i>못 가져옴</i>")

    if 관심결과:
        줄들 += ["", "⭐ <b>관심종목</b>"]
        for 이름, 값, 율 in 관심결과:
            줄들.append("· " + 한줄(이스케이프(이름), 값, 율, 소수=0, 꼬리="원"))
    if 못찾음:
        줄들.append(f"<i>· 이름을 못 찾음: {이스케이프(', '.join(못찾음))} "
                    f"(종목코드 6자리로 적어주세요)</i>")

    줄들 += ["", "<i>장이 열리기 전이면 어제 종가입니다.</i>",
           "<i>자료: Yahoo Finance 외 · 지연 시세 · 투자 판단은 본인 책임</i>"]
    return "\n".join(줄들)


# ────────────────────────────────────────────────────────────
# 6. 텔레그램으로 보내기
# ────────────────────────────────────────────────────────────
def 텔레그램전송(토큰, 챗아이디, 본문):
    자료 = urllib.parse.urlencode({
        "chat_id": 챗아이디,
        "text": 본문,
        "parse_mode": "HTML",
        "disable_web_page_preview": "true",
    }).encode("utf-8")
    req = urllib.request.Request(
        f"https://api.telegram.org/bot{토큰}/sendMessage",
        data=자료, headers={"Content-Type": "application/x-www-form-urlencoded"})
    with urllib.request.urlopen(req, timeout=20) as r:
        return json.loads(r.read().decode("utf-8"))


def 텔레그램오류설명(e):
    """텔레그램이 거절했을 때, 왕초보가 바로 손댈 수 있는 말로 바꿔줍니다."""
    본문 = ""
    코드 = getattr(e, "code", None)
    try:
        본문 = e.read().decode("utf-8", "replace")
    except Exception:
        pass
    설명 = 본문
    try:
        설명 = json.loads(본문).get("description", 본문)
    except Exception:
        pass
    낮춤 = (설명 or "").lower()

    if 코드 == 401 or "unauthorized" in 낮춤:
        return ("봇 토큰(열쇠)이 틀렸습니다.\n"
                "     → 텔레그램 BotFather 에게 /mybots 로 다시 받아 설정.txt 의 '봇토큰' 에 붙여넣으세요.\n"
                "     → 앞뒤에 따옴표나 빈칸이 붙지 않았는지 확인하세요.")
    if "chat not found" in 낮춤:
        return ("챗 ID를 못 찾았습니다. 둘 중 하나입니다.\n"
                "     → ① 챗 ID 숫자가 틀렸습니다 (userinfobot 에서 다시 확인)\n"
                "     → ② 내 봇에게 아직 말을 안 걸었습니다. 텔레그램에서 내 봇을 찾아\n"
                "          /start 를 한 번 보낸 뒤 다시 실행하세요. (이게 제일 흔합니다)")
    if 코드 == 404 or "not found" == 낮춤.strip():
        return ("봇 토큰(열쇠)이 깨졌습니다. 복사할 때 일부가 빠진 경우입니다.\n"
                "     → BotFather 대화방에서 열쇠 줄을 '한 번 눌러 전체 복사' 한 뒤\n"
                "       설정.txt 의 '봇토큰' 에 통째로 붙여넣으세요.")
    if 코드 == 403 or "blocked" in 낮춤:
        return "봇을 차단해 두셨습니다. 텔레그램에서 내 봇 대화방을 열고 차단 해제 후 다시 실행하세요."
    if "can't parse entities" in 낮춤:
        return "메시지 서식 오류입니다. 이 화면을 통째로 캡처해서 그밤PD에게 보여주세요."
    return f"텔레그램이 거절했습니다: {설명 or e}"


# ────────────────────────────────────────────────────────────
# 7. 실행
# ────────────────────────────────────────────────────────────
def main():
    미리보기 = any(a in ("--미리보기", "--preview", "-p") for a in sys.argv[1:])

    print("=" * 46)
    print("  시황 키트 v1.0  ·  그밤PD 챌린지")
    print("=" * 46)

    토큰, 챗아이디, 관심, 제목 = 설정읽기()

    if not 미리보기 and (not 토큰 or not 챗아이디):
        print("\n✖ 아직 열쇠가 없습니다.\n")
        if not os.path.exists(설정파일) and not os.environ.get("BOT_TOKEN"):
            print(f"   '설정.txt' 파일이 안 보입니다. 이 파일과 같은 폴더에 있어야 합니다.\n   (찾는 위치: {설정파일})")
        else:
            없는것 = []
            if not 토큰:
                없는것.append("봇토큰")
            if not 챗아이디:
                없는것.append("챗ID")
            print(f"   설정.txt 에서 다음 값이 비어 있습니다 → {', '.join(없는것)}")
        print("\n   ▶ 열쇠 없이 모양만 먼저 보고 싶다면:  python 시황.py --미리보기")
        print("   ▶ 무엇이 문제인지 하나씩 점검하려면:  python 점검.py\n")
        sys.exit(1)

    # 보내기 전에 미리 걸러내면, 엉뚱한 오류 메시지를 보고 헤매지 않습니다
    if not 미리보기 and not (챗아이디.startswith("@") or 챗아이디.lstrip("-").isdigit()):
        print(f"\n✖ 챗 ID가 숫자가 아닙니다: '{챗아이디}'\n")
        print("   챗 ID는 이름이 아니라 '번호'입니다. 예) 1234567890")
        print("   → 텔레그램에서 userinfobot 을 찾아 아무 말이나 보내면 알려줍니다.")
        print("   → 그 숫자를 설정.txt 의 '챗ID' 에 붙여넣으세요.\n")
        sys.exit(1)

    본문 = 메시지만들기(제목, 관심)

    if 미리보기:
        print("\n[3/3] 미리보기 (보내지 않았습니다)")
        print("-" * 46)
        print(본문.replace("<b>", "").replace("</b>", "")
                .replace("<i>", "").replace("</i>", "")
                .replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">"))
        print("-" * 46)
        print("\n실제로 보내려면:  python 시황.py\n")
        return

    print("\n[3/3] 텔레그램으로 보냅니다…")
    try:
        텔레그램전송(토큰, 챗아이디, 본문)
    except urllib.error.HTTPError as e:
        print(f"\n✖ 못 보냈습니다.\n     {텔레그램오류설명(e)}\n")
        print("   ▶ 하나씩 점검하려면:  python 점검.py\n")
        sys.exit(1)
    except Exception as e:
        print(f"\n✖ 못 보냈습니다 (인터넷 문제일 수 있습니다): {type(e).__name__}: {e}\n")
        print("   ▶ 하나씩 점검하려면:  python 점검.py\n")
        sys.exit(1)

    print("\n✔ 보냈습니다! 폰에서 텔레그램을 확인하세요.\n")


if __name__ == "__main__":
    main()
