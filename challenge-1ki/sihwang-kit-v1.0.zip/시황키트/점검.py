# -*- coding: utf-8 -*-
"""
점검 — "왜 안 되지?" 싶을 때 이걸 먼저 돌리세요.
무엇이 되고 무엇이 안 되는지 하나씩 확인해서 알려줍니다.

실행:  python 점검.py

이 화면에는 열쇠가 ●●●● 로 가려져 나옵니다.
그래서 그대로 캡처해서 단톡방에 올려도 안전합니다.
"""

import sys
import os
import json
import urllib.request
import urllib.parse
import urllib.error

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

여기 = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, 여기)

합격, 불합격 = [], []


def 줄(제목):
    print("\n" + "─" * 46)
    print(f"  {제목}")
    print("─" * 46)


def 확인(이름, 성공, 메모=""):
    print(f"  {'✔' if 성공 else '✖'} {이름}" + (f"  —  {메모}" if 메모 else ""))
    (합격 if 성공 else 불합격).append(이름)
    return 성공


def 가리기(값, 앞=0):
    """열쇠를 화면에 안 드러내면서도 '들어있긴 하다'를 보여줍니다."""
    if not 값:
        return "(비어 있음)"
    if 앞 and len(값) > 앞:
        return 값[:앞] + "●" * 8 + f" (총 {len(값)}글자)"
    return "●" * 8 + f" (총 {len(값)}글자)"


print("=" * 46)
print("  시황 키트 점검  ·  그밤PD 챌린지")
print("=" * 46)
print("  ※ 열쇠는 ●●●● 로 가려집니다. 캡처해서 올려도 안전합니다.")

# ── 1. 컴퓨터 준비 상태 ────────────────────────────────────
줄("1. 파이썬과 파일")
확인(f"파이썬 {sys.version_info.major}.{sys.version_info.minor}",
   sys.version_info >= (3, 8),
   "3.8 이상이면 됩니다" if sys.version_info >= (3, 8) else "너무 낮습니다. 파이썬을 새로 설치하세요")
확인("시황.py 가 같은 폴더에 있음", os.path.exists(os.path.join(여기, "시황.py")),
   여기)

설정있음 = os.path.exists(os.path.join(여기, "설정.txt"))
액션에서돎 = bool(os.environ.get("GITHUB_ACTIONS"))
if 액션에서돎:
    print("  · 지금 깃허브 액션 안에서 돌고 있습니다 — 열쇠는 금고(Secrets)에서 가져옵니다")
    확인("금고에서 열쇠를 받았음", bool(os.environ.get("BOT_TOKEN")),
       "설정.txt 는 여기 없는 게 정상입니다" if os.environ.get("BOT_TOKEN")
       else "금고에 BOT_TOKEN 을 넣었는지, 이름 철자가 맞는지 확인하세요")
else:
    확인("설정.txt 가 같은 폴더에 있음", 설정있음,
       "" if 설정있음 else "키트 폴더 안에 설정.txt 가 있어야 합니다")

try:
    import 시황 as K
except Exception as e:
    print(f"\n  ✖ 시황.py 를 불러오지 못했습니다: {type(e).__name__}: {e}")
    print("     이 화면을 통째로 캡처해서 그밤PD에게 보여주세요.\n")
    sys.exit(1)

# ── 2. 설정값 ──────────────────────────────────────────────
줄("2. 내가 넣은 값")
토큰, 챗아이디, 관심, 제목 = K.설정읽기()

확인("봇토큰이 채워져 있음", bool(토큰), 가리기(토큰, 앞=0))
if 토큰:
    모양맞음 = (":" in 토큰) and 토큰.split(":")[0].isdigit() and len(토큰.split(":")[-1]) > 20
    확인("봇토큰 생김새가 맞음", 모양맞음,
       "맞습니다" if 모양맞음 else "'숫자:영문숫자' 모양이어야 합니다. 복사할 때 일부가 빠졌을 수 있어요")
    if 토큰 != 토큰.strip() or " " in 토큰:
        확인("봇토큰에 빈칸이 섞여 있지 않음", False, "앞뒤 빈칸이나 줄바꿈을 지워주세요")

확인("챗ID가 채워져 있음", bool(챗아이디), 가리기(챗아이디, 앞=3))
if 챗아이디:
    확인("챗ID가 숫자임", 챗아이디.lstrip("-").isdigit(),
       "맞습니다" if 챗아이디.lstrip("-").isdigit() else "숫자만 있어야 합니다 (이름이 아니라 번호)")

if 관심.strip():
    목록, 못찾음 = K.관심종목찾기(관심)
    확인(f"관심종목 {len(목록)}개 인식", not 못찾음,
       ", ".join(n for n, _, _ in 목록) if not 못찾음
       else f"못 찾은 이름: {', '.join(못찾음)} → 종목코드 6자리로 적어주세요")
else:
    print("  · 관심종목은 비어 있습니다 (없어도 잘 돌아갑니다)")

# ── 3. 인터넷과 시세 ───────────────────────────────────────
줄("3. 시세를 가져올 수 있나")
소스 = [
    ("코스피 (야후)", lambda: K.야후("^KS11")),
    ("코스닥 (야후)", lambda: K.야후("^KQ11")),
    ("S&P500 (야후)", lambda: K.야후("^GSPC")),
    ("나스닥 (야후)", lambda: K.야후("^IXIC")),
    ("원/달러 (야후)", lambda: K.야후("KRW=X")),
    ("비트코인 (야후)", lambda: K.야후("BTC-KRW")),
]
야후성공 = 0
for 이름, 함수 in 소스:
    try:
        지금, 전일 = 함수()
        율 = (지금 - 전일) / 전일 * 100
        if 확인(이름, True, f"{지금:,.2f} ({율:+.2f}%)"):
            야후성공 += 1
    except Exception as e:
        확인(이름, False, f"{type(e).__name__}")

print("\n  [예비 소스 — 위가 막혔을 때 대신 쓰는 곳]")
for 이름, 함수 in [("코스피 (네이버)", lambda: K.네이버지수("KOSPI")),
              ("환율 (프랑크푸르터)", K.프랑크푸르터),
              ("비트코인 (업비트)", K.업비트)]:
    try:
        값, 율 = 함수()
        확인(이름, True, f"{값:,.2f} ({율:+.2f}%)")
    except Exception as e:
        확인(이름, False, f"{type(e).__name__}")

if 야후성공 == 0:
    print("\n  ⚠️ 시세를 한 개도 못 가져왔습니다. 인터넷 연결이나 회사 보안프로그램을 확인하세요.")

# ── 4. 텔레그램 ────────────────────────────────────────────
줄("4. 텔레그램 봇")
if not 토큰 or not 챗아이디:
    print("  · 열쇠가 없어서 건너뜁니다. 설정.txt 를 먼저 채워주세요.")
else:
    봇이름 = None
    try:
        req = urllib.request.Request(f"https://api.telegram.org/bot{토큰}/getMe")
        with urllib.request.urlopen(req, timeout=15) as r:
            정보 = json.loads(r.read().decode("utf-8"))["result"]
        봇이름 = 정보.get("username")
        확인("토큰이 살아있음", True, f"봇 이름: @{봇이름}")
    except urllib.error.HTTPError as e:
        확인("토큰이 살아있음", False, K.텔레그램오류설명(e).split("\n")[0])
    except Exception as e:
        확인("토큰이 살아있음", False, f"{type(e).__name__} (인터넷 문제일 수 있습니다)")

    if 봇이름:
        try:
            K.텔레그램전송(토큰, 챗아이디, "🔧 점검 메시지입니다. 이게 보이면 연결이 정상입니다.")
            확인("내 폰으로 발송", True, "텔레그램을 확인해보세요")
        except urllib.error.HTTPError as e:
            확인("내 폰으로 발송", False, "")
            print("     " + K.텔레그램오류설명(e))
        except Exception as e:
            확인("내 폰으로 발송", False, f"{type(e).__name__}")

# ── 5. 요약 ────────────────────────────────────────────────
줄("점검 결과")
print(f"  잘 되는 것 {len(합격)}개 · 안 되는 것 {len(불합격)}개")
if 불합격:
    print("\n  손봐야 할 것:")
    for x in 불합격:
        print(f"    ✖ {x}")
    print("\n  ▶ 위에 적힌 안내대로 고쳐보고, 그래도 안 되면")
    print("    이 화면을 통째로 캡처해서 AI에게 또는 단톡방에 올려주세요.")
    print("    (열쇠는 가려져 있으니 그대로 올리셔도 됩니다)")
else:
    print("\n  ✔ 전부 정상입니다. 이제 'python 시황.py' 를 실행하세요.")
print()
