# -*- coding: utf-8 -*-
"""
영상 키트 — 대본(txt)과 음성(mp3)을 넣으면 자막이 붙은 영상(mp4)을 만들어주는 프로그램
그밤PD 챌린지 1기 · 3주차 배포 재료 (v1.0)

이 파일은 고치지 않아도 됩니다. 고칠 것은 '설정.txt' 하나뿐입니다.

실행:  python 영상만들기.py            → 전체 영상을 만듭니다 (몇 분 걸립니다)
       python 영상만들기.py --맛보기   → 앞부분 40초만 빠르게 만들어 자막 싱크만 확인
       python 영상만들기.py --자막만   → 영상 없이 자막 파일만 만들어 시각을 확인

만든 사람: 그밤PD · 필요한 프로그램: 파이썬 + ffmpeg (README 참고)
"""

import sys
import os
import re
import json
import shutil
import subprocess

# 윈도우 검은 창(cmd)에서 한글이 깨지지 않게 하는 안전장치
try:
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
except Exception:
    pass

여기 = os.path.dirname(os.path.abspath(__file__))
설정파일 = os.path.join(여기, "설정.txt")

# 재료를 찾을 폴더: 키트 폴더 자신과 그 바로 위(부모) 폴더
재료폴더후보 = [여기, os.path.dirname(여기)]

음성확장자 = (".mp3", ".wav", ".m4a", ".aac", ".ogg", ".flac")
이미지확장자 = (".jpg", ".jpeg", ".png", ".webp")

# 재료로 오인하면 안 되는 파일들 (키트 자신의 문서와 결과물)
#  ※ 키트가 만든 '_자막시각표.txt' 를 대본으로 잡는 사고가 실제로 있었습니다.
#    그래서 밑줄(_)로 시작하는 파일은 재료 후보에서 뺍니다.
제외파일 = ("readme.md", "설정.txt", "자주묻는질문.md", "requirements.txt")


# ══════════════════════════════════════════════════════════════
#  화면 안내 (왕초보용 — 지금 뭐 하는 중인지 계속 알려줍니다)
# ══════════════════════════════════════════════════════════════

def 안내(글):
    print(글, flush=True)


def 제목줄(글):
    print("\n" + "─" * 58, flush=True)
    print("  " + 글, flush=True)
    print("─" * 58, flush=True)


def 그만(이유, 해결=None):
    print("\n❌ " + 이유, flush=True)
    if 해결:
        print("\n👉 이렇게 해보세요:\n   " + 해결.replace("\n", "\n   "), flush=True)
    print("\n(그래도 안 되면 이 검은 창을 통째로 캡처해서 AI에게 보여주세요.)", flush=True)
    sys.exit(1)


# ══════════════════════════════════════════════════════════════
#  설정 읽기
# ══════════════════════════════════════════════════════════════

기본설정 = {
    "제목": "",
    "배경색": "짙은남색",
    "글자색": "흰색",
    "강조색": "금색",
    "배경이미지": "",
    "글자크기": "58",
    "한줄글자수": "18",
    "자막당김": "0",
    "화면크기": "가로",
}

색이름표 = {
    "검정": "000000", "검은색": "000000", "블랙": "000000",
    "흰색": "FFFFFF", "하양": "FFFFFF", "화이트": "FFFFFF",
    "짙은남색": "0D1B3E", "남색": "13245C", "네이비": "0D1B3E",
    "짙은회색": "1C1C1C", "회색": "808080",
    "금색": "FFC94A", "골드": "FFC94A", "노랑": "FFD400", "노란색": "FFD400",
    "빨강": "E23B3B", "빨간색": "E23B3B",
    "파랑": "2E6BE6", "파란색": "2E6BE6", "하늘색": "58B8F0",
    "초록": "36B37E", "초록색": "36B37E",
    "보라": "7A5AF8", "보라색": "7A5AF8",
    "분홍": "F06AA0", "핑크": "F06AA0",
    "주황": "F58A2E", "주황색": "F58A2E",
    "갈색": "6B4A2F", "크림": "F5E9D6",
}


def 설정읽기():
    설정 = dict(기본설정)
    if not os.path.exists(설정파일):
        return 설정
    try:
        with open(설정파일, "r", encoding="utf-8") as f:
            원문 = f.read()
    except Exception:
        return 설정
    for 줄 in 원문.splitlines():
        줄 = 줄.strip()
        if not 줄 or 줄.startswith("#"):
            continue
        if "=" not in 줄:
            continue
        키, _, 값 = 줄.partition("=")
        키 = 키.strip()
        값 = 값.strip().strip('"').strip("'")
        if 키 in 설정:
            설정[키] = 값
    return 설정


def 색코드(값, 기본="FFFFFF"):
    """'금색' 또는 '#FFC94A' 또는 'FFC94A' → 'FFC94A' (RRGGBB)"""
    if not 값:
        return 기본
    값 = 값.strip()
    if 값 in 색이름표:
        return 색이름표[값]
    후보 = 값.lstrip("#").upper()
    if re.fullmatch(r"[0-9A-F]{6}", 후보):
        return 후보
    return 기본


def ass색(rrggbb):
    """RRGGBB → ASS 형식 &H00BBGGRR"""
    r, g, b = rrggbb[0:2], rrggbb[2:4], rrggbb[4:6]
    return "&H00" + b + g + r


def 숫자(값, 기본):
    try:
        return float(str(값).replace("초", "").strip())
    except Exception:
        return 기본


# ══════════════════════════════════════════════════════════════
#  ffmpeg 찾기
# ══════════════════════════════════════════════════════════════

def ffmpeg찾기():
    for 이름 in ("ffmpeg", "ffmpeg.exe"):
        경로 = shutil.which(이름)
        if 경로:
            return 경로
    return None


def ffprobe찾기():
    for 이름 in ("ffprobe", "ffprobe.exe"):
        경로 = shutil.which(이름)
        if 경로:
            return 경로
    return None


def 실행(명령, 화면표시=False):
    """ffmpeg 실행. 화면표시=True면 진행 상황을 그대로 흘려보냅니다."""
    if 화면표시:
        결과 = subprocess.run(명령)
        return 결과.returncode, "", ""
    결과 = subprocess.run(명령, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    나온글 = 결과.stdout.decode("utf-8", "replace")
    오류글 = 결과.stderr.decode("utf-8", "replace")
    return 결과.returncode, 나온글, 오류글


# ══════════════════════════════════════════════════════════════
#  재료 찾기 (대본 txt · 음성 mp3 · 배경 이미지)
# ══════════════════════════════════════════════════════════════

def 재료찾기(설정):
    대본, 음성, 이미지 = None, None, None

    for 폴더 in 재료폴더후보:
        if not os.path.isdir(폴더):
            continue
        try:
            파일들 = sorted(os.listdir(폴더))
        except Exception:
            continue

        대본후보, 음성후보 = [], []
        for 이름 in 파일들:
            낮은이름 = 이름.lower()
            전체 = os.path.join(폴더, 이름)
            if not os.path.isfile(전체):
                continue
            if 낮은이름 in 제외파일 or 이름.startswith("_") or 이름.startswith("~"):
                continue

            if 낮은이름.endswith(".txt"):
                대본후보.append(전체)
            if 낮은이름.endswith(음성확장자):
                음성후보.append(전체)
            if 이미지 is None and 낮은이름.endswith(이미지확장자):
                이미지 = 전체

        # 이름에 '대본'/'음성'이 들어간 파일을 먼저 씁니다 (없으면 첫 번째)
        if 대본 is None and 대본후보:
            대본 = next((p for p in 대본후보 if "대본" in os.path.basename(p)
                        or "script" in os.path.basename(p).lower()), 대본후보[0])
        if 음성 is None and 음성후보:
            음성 = next((p for p in 음성후보 if "음성" in os.path.basename(p)
                        or "voice" in os.path.basename(p).lower()), 음성후보[0])

        if 대본 and 음성:
            break

    # 설정에서 배경이미지를 직접 지정했으면 그걸 우선
    지정이미지 = 설정.get("배경이미지", "").strip()
    if 지정이미지:
        찾음 = None
        for 폴더 in 재료폴더후보:
            후보 = os.path.join(폴더, 지정이미지)
            if os.path.isfile(후보):
                찾음 = 후보
                break
        if 찾음:
            이미지 = 찾음
        else:
            안내("   ⚠️ 설정.txt 의 배경이미지 '%s' 를 못 찾아서 단색 배경으로 만듭니다." % 지정이미지)
            이미지 = None
    else:
        이미지 = None  # 지정하지 않았으면 단색 배경 (썸네일이 섞여 들어가는 사고 방지)

    return 대본, 음성, 이미지


# ══════════════════════════════════════════════════════════════
#  대본 → 자막 줄 나누기
# ══════════════════════════════════════════════════════════════

문장끝 = re.compile(r"(?<=[.!?。！？…])\s+")


def 대본읽기(경로):
    원문 = None
    for 인코딩 in ("utf-8", "utf-8-sig", "cp949", "euc-kr"):
        try:
            with open(경로, "r", encoding=인코딩) as f:
                원문 = f.read()
            break
        except UnicodeDecodeError:
            continue
    if 원문 is None:
        그만("대본 파일을 읽지 못했습니다: " + os.path.basename(경로),
             "대본을 메모장에서 열고 [파일 → 다른 이름으로 저장]에서\n인코딩을 'UTF-8'로 바꿔 저장한 뒤 다시 해보세요.")
    return 원문


def 자막줄만들기(원문, 한줄글자수, 최대줄수=2):
    """대본을 화면에 뜰 자막 덩어리(큐)로 나눕니다. 한 큐 = 최대 2줄."""
    한큐최대 = 한줄글자수 * 최대줄수

    # 1) 문단·문장 단위로 1차 분해
    조각들 = []
    for 문단 in 원문.splitlines():
        문단 = 문단.strip()
        if not 문단:
            continue
        # 대본에 [지시문] 같은 표시가 있으면 자막에서 뺍니다
        문단 = re.sub(r"^\s*[\[\(#*\-]+\s*", "", 문단)
        문단 = re.sub(r"[\]\)]\s*$", "", 문단) if 문단.startswith("[") else 문단
        if not 문단.strip():
            continue
        for 문장 in 문장끝.split(문단):
            문장 = 문장.strip()
            if 문장:
                조각들.append(문장)

    # 2) 너무 긴 문장은 쉼표·띄어쓰기에서 더 자릅니다
    큐들 = []
    for 조각 in 조각들:
        if len(조각) <= 한큐최대:
            큐들.append(조각)
            continue
        남은 = 조각
        while len(남은) > 한큐최대:
            자를곳 = -1
            # 쉼표 우선
            for 표시 in (", ", "， ", ",", "·"):
                위치 = 남은.rfind(표시, 0, 한큐최대 + 1)
                if 위치 > 한큐최대 * 0.45:
                    자를곳 = 위치 + len(표시)
                    break
            if 자를곳 < 0:
                위치 = 남은.rfind(" ", 0, 한큐최대 + 1)
                자를곳 = 위치 + 1 if 위치 > 한큐최대 * 0.45 else 한큐최대
            큐들.append(남은[:자를곳].strip())
            남은 = 남은[자를곳:].strip()
        if 남은:
            큐들.append(남은)

    # 3) 화면 표시용 줄바꿈(\N) 넣기 + '문장 시작인가' 표시
    #    긴 문장을 쪼갠 뒷조각은 '이어지는 자막'이라 말이 새로 시작되지 않습니다.
    완성 = []
    for i, 큐 in enumerate(큐들):
        if i == 0:
            문장시작 = True
        else:
            앞글 = 큐들[i - 1].rstrip()
            문장시작 = bool(앞글) and 앞글[-1] in ".!?。！？…"
        완성.append((큐, 줄바꿈넣기(큐, 한줄글자수), 문장시작))
    return 완성


def 줄바꿈넣기(글, 한줄글자수):
    if len(글) <= 한줄글자수:
        return 글
    가운데 = len(글) // 2
    위치 = 글.rfind(" ", 0, 가운데 + 6)
    if 위치 < 한줄글자수 * 0.3:
        위치 = 글.find(" ", 가운데)
    if 위치 <= 0:
        위치 = 가운데
    return (글[:위치].strip() + "\\N" + 글[위치:].strip())


# ══════════════════════════════════════════════════════════════
#  음성 분석 — 길이와 '말이 시작되는 지점'
# ══════════════════════════════════════════════════════════════

def 음성길이(ffprobe, 음성):
    코드, 나온글, _ = 실행([ffprobe, "-v", "error", "-show_entries", "format=duration",
                          "-of", "json", 음성])
    if 코드 != 0:
        return None
    try:
        return float(json.loads(나온글)["format"]["duration"])
    except Exception:
        return None


def 말시작지점찾기(ffmpeg, 음성, 기준dB=-32, 최소무음=0.20):
    """
    ffmpeg 의 무음 감지로 '조용했다가 말이 시작되는 시각' 목록을 뽑습니다.
    자막은 말이 시작될 때 떠야 하므로, 이 지점들이 자막 시작 후보가 됩니다.
    """
    코드, _, 오류글 = 실행([
        ffmpeg, "-hide_banner", "-nostats", "-i", 음성,
        "-af", "silencedetect=noise=%ddB:d=%s" % (기준dB, 최소무음),
        "-f", "null", "-"
    ])
    무음시작, 무음끝 = [], []
    for 줄 in 오류글.splitlines():
        m = re.search(r"silence_start:\s*(-?[\d.]+)", 줄)
        if m:
            무음시작.append(float(m.group(1)))
        m = re.search(r"silence_end:\s*(-?[\d.]+)", 줄)
        if m:
            무음끝.append(float(m.group(1)))
    return 무음시작, 무음끝


def 시각배정(큐들, 총길이, 무음시작, 무음끝, 짧은쉼=None, 당김=0.0):
    """
    2단으로 맞춥니다.
    ① 문장이 새로 시작되는 자막 → 실제 '말 시작 지점'에 딱 붙입니다(앵커).
    ② 긴 문장을 쪼갠 '이어지는 자막' → 앵커와 앵커 사이를 글자 수로 다시 나눕니다.
       (전체 비율로만 잡으면 문장 사이 쉼 때문에 뒤로 밀립니다)
    → 위스퍼 같은 무거운 프로그램 없이도 자막이 목소리에 붙습니다.
    """
    말시작후보 = sorted(무음끝)
    짧은쉼 = sorted(짧은쉼 or [])

    # 말이 실제로 시작/끝나는 구간
    첫말 = 0.0
    if 무음시작 and 무음시작[0] <= 0.35 and 무음끝:
        첫말 = 무음끝[0]
    elif 말시작후보 and 말시작후보[0] < 1.5 and (not 무음시작 or 무음시작[0] < 0.35):
        첫말 = 말시작후보[0]

    끝말 = 총길이
    if 무음시작 and (not 무음끝 or 무음시작[-1] > 무음끝[-1]):
        끝말 = max(무음시작[-1], 첫말 + 1.0)  # 마지막이 무음으로 끝나는 경우

    말구간 = max(끝말 - 첫말, 1.0)

    글자수 = [max(len(re.sub(r"\s", "", 원문)), 1) for 원문, _, _ in 큐들]
    전체글자 = sum(글자수)

    # ── 1단계: 전체 글자 비율로 대략의 시각 ─────────────────
    대략 = []
    누적 = 0
    for n in 글자수:
        대략.append(첫말 + 말구간 * (누적 / 전체글자))
        누적 += n

    # ── 2단계: 문장 시작 자막만 실제 발화 지점에 붙입니다 ────
    허용 = 0.80
    확정 = [None] * len(큐들)
    직전 = -1.0
    for i, (원문, 표시, 문장시작) in enumerate(큐들):
        if not 문장시작:
            continue
        목표 = 대략[i]
        고른값 = 목표
        if 말시작후보:
            가까운 = min(말시작후보, key=lambda t: abs(t - 목표))
            if abs(가까운 - 목표) <= 허용 and 가까운 > 직전 + 0.35:
                고른값 = 가까운
        if 고른값 <= 직전 + 0.35:
            고른값 = 직전 + 0.35
        확정[i] = 고른값
        직전 = 고른값

    if 확정[0] is None:
        확정[0] = 첫말

    # ── 3단계: 이어지는 자막을 앵커 사이에 다시 나눕니다 ─────
    i = 0
    while i < len(큐들):
        if 확정[i] is None:
            i += 1
            continue
        # 다음 앵커 찾기
        j = i + 1
        while j < len(큐들) and 확정[j] is None:
            j += 1
        사이 = list(range(i + 1, j))  # 이어지는 자막들
        if 사이:
            시작점 = 확정[i]
            # 이 문장의 말이 실제로 끝나는 지점 = 다음 앵커 직전의 무음 시작
            다음앵커 = 확정[j] if j < len(큐들) else 끝말
            말끝 = 다음앵커
            앞무음 = [s for s in 무음시작 if 시작점 + 0.3 < s < 다음앵커 - 0.05]
            if 앞무음:
                말끝 = max(앞무음)
            폭 = max(말끝 - 시작점, 0.8)

            그룹 = [i] + 사이
            그룹글자 = [글자수[k] for k in 그룹]
            합 = sum(그룹글자)
            누적 = 그룹글자[0]
            for 자리, k in enumerate(사이, start=1):
                목표 = 시작점 + 폭 * (누적 / 합)
                누적 += 그룹글자[자리]
                # 짧은 숨(쉼표 등)이 아주 가까이 있으면 거기에 붙입니다
                if 짧은쉼:
                    가까운 = min(짧은쉼, key=lambda t: abs(t - 목표))
                    if abs(가까운 - 목표) <= 0.35:
                        목표 = 가까운
                확정[k] = 목표
        i = j

    # 빈 곳 메우기 + 순서 보장
    직전 = -1.0
    for i in range(len(확정)):
        if 확정[i] is None:
            확정[i] = 직전 + 0.8
        if 확정[i] <= 직전 + 0.35:
            확정[i] = 직전 + 0.35
        직전 = 확정[i]

    # ── 4단계: 끝 시각 = 다음 자막 시작 (마지막은 음성 끝까지) ──
    시각들 = []
    for i, 시작 in enumerate(확정):
        끝 = 확정[i + 1] if i + 1 < len(확정) else min(끝말 + 0.6, 총길이)
        끝 = max(끝, 시작 + 0.6)
        시작보정 = max(0.0, 시작 - 당김)
        끝보정 = max(시작보정 + 0.6, 끝 - 당김)
        시각들.append((시작보정, min(끝보정, 총길이)))
    return 시각들


# ══════════════════════════════════════════════════════════════
#  자막 파일(ASS) 만들기
# ══════════════════════════════════════════════════════════════

def 시각글자(초):
    if 초 < 0:
        초 = 0
    시 = int(초 // 3600)
    분 = int((초 % 3600) // 60)
    남 = 초 % 60
    return "%d:%02d:%05.2f" % (시, 분, 남)


def ass만들기(큐들, 시각들, 설정, 가로, 세로, 저장경로, 이미지있음=False):
    글자색 = ass색(색코드(설정.get("글자색"), "FFFFFF"))
    강조 = ass색(색코드(설정.get("강조색"), "FFC94A"))
    크기 = int(숫자(설정.get("글자크기"), 58))
    if 세로 > 가로:  # 세로 영상이면 글자를 조금 키웁니다
        크기 = int(크기 * 1.15)
    아래여백 = int(세로 * 0.10)
    제목 = 설정.get("제목", "").strip()

    # 배경 그림이 있으면 그림을 가리지 않게 아래쪽(2), 단색 배경이면 화면 가운데(5).
    # 단색인데 아래에 붙이면 화면 위쪽이 텅 비어 허전해 보입니다.
    자막위치 = 2 if 이미지있음 else 5

    머리 = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {가로}
PlayResY: {세로}
WrapStyle: 2
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: 자막,Malgun Gothic,{크기},{글자색},{글자색},&H00000000,&H90000000,-1,0,0,0,100,100,0,0,1,3,2,{자막위치},{int(가로*0.06)},{int(가로*0.06)},{아래여백},1
Style: 제목,Malgun Gothic,{int(크기*0.62)},{강조},{강조},&H00000000,&H90000000,-1,0,0,0,100,100,0,0,1,2,1,8,{int(가로*0.05)},{int(가로*0.05)},{int(세로*0.055)},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""

    줄들 = []
    if 제목 and 시각들:
        끝 = 시각들[-1][1]
        줄들.append("Dialogue: 0,%s,%s,제목,,0,0,0,,%s" %
                    (시각글자(0), 시각글자(끝), 제목.replace("\n", " ")))

    for (원문, 표시, _), (시작, 끝) in zip(큐들, 시각들):
        본문 = 표시.replace("{", "(").replace("}", ")")
        줄들.append("Dialogue: 0,%s,%s,자막,,0,0,0,,%s" % (시각글자(시작), 시각글자(끝), 본문))

    with open(저장경로, "w", encoding="utf-8") as f:
        f.write(머리 + "\n".join(줄들) + "\n")


# ══════════════════════════════════════════════════════════════
#  영상 만들기 (렌더)
# ══════════════════════════════════════════════════════════════

def ass경로escape(경로):
    """ffmpeg 필터에 넣을 때 윈도우 경로의 역슬래시와 콜론을 처리합니다."""
    경로 = 경로.replace("\\", "/")
    경로 = 경로.replace(":", "\\:")
    return 경로


def 렌더(ffmpeg, 음성, ass, 이미지, 배경색, 가로, 세로, 저장경로, 맛보기초=0):
    명령 = [ffmpeg, "-y", "-hide_banner"]

    if 이미지:
        명령 += ["-loop", "1", "-i", 이미지]
    else:
        명령 += ["-f", "lavfi", "-i", "color=c=0x%s:s=%dx%d:r=30" % (배경색, 가로, 세로)]

    명령 += ["-i", 음성]

    if 이미지:
        필터 = ("[0:v]scale=%d:%d:force_original_aspect_ratio=increase,"
                "crop=%d:%d,setsar=1,boxblur=0:0[bg];"
                "[bg]ass='%s'[v]") % (가로, 세로, 가로, 세로, ass경로escape(ass))
    else:
        필터 = "[0:v]ass='%s'[v]" % ass경로escape(ass)

    명령 += ["-filter_complex", 필터, "-map", "[v]", "-map", "1:a"]

    if 맛보기초 > 0:
        명령 += ["-t", str(맛보기초)]

    명령 += [
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "23",
        "-pix_fmt", "yuv420p", "-r", "30",
        "-c:a", "aac", "-b:a", "192k",
        "-shortest", "-movflags", "+faststart",
        저장경로
    ]
    코드, _, 오류글 = 실행(명령)
    return 코드, 오류글


# ══════════════════════════════════════════════════════════════
#  본 실행
# ══════════════════════════════════════════════════════════════

def main():
    맛보기 = "--맛보기" in sys.argv
    자막만 = "--자막만" in sys.argv

    제목줄("🎬 영상 키트 v1.0 — 대본 + 음성 → 자막 영상")

    설정 = 설정읽기()

    # ── 1. 프로그램 확인 ─────────────────────────────
    ffmpeg = ffmpeg찾기()
    ffprobe = ffprobe찾기()
    if not 자막만:
        if not ffmpeg:
            그만("영상을 만드는 프로그램(ffmpeg)이 컴퓨터에 없습니다.",
                 "이 검은 창에 아래를 붙여넣고 엔터를 누르세요 (2~5분 걸립니다):\n\n"
                 "    winget install Gyan.FFmpeg\n\n"
                 "설치가 끝나면 VS Code를 껐다 켠 뒤 다시 실행하세요.\n"
                 "(껐다 켜야 새로 깐 프로그램을 알아봅니다)")
    if not ffprobe:
        ffprobe = ffmpeg  # ffprobe가 없어도 ffmpeg로 길이를 구할 수 있게

    # ── 2. 재료 찾기 ────────────────────────────────
    대본, 음성, 이미지 = 재료찾기(설정)
    if not 대본:
        그만("대본 파일(.txt)을 못 찾았습니다.",
             "대본을 '대본.txt' 라는 이름으로 저장해서\n이 키트 폴더 또는 그 바로 위 폴더에 넣어주세요.")
    if not 음성:
        그만("음성 파일(.mp3)을 못 찾았습니다.",
             "일레븐랩스에서 내려받은 파일을 '음성.mp3' 라는 이름으로\n이 키트 폴더 또는 그 바로 위 폴더에 넣어주세요.")

    안내("📄 대본  : " + os.path.basename(대본))
    안내("🔊 음성  : " + os.path.basename(음성))
    안내("🖼  배경  : " + (os.path.basename(이미지) if 이미지 else "단색 (%s)" % 설정.get("배경색")))

    # ── 3. 대본 나누기 ──────────────────────────────
    한줄글자수 = int(숫자(설정.get("한줄글자수"), 18))
    큐들 = 자막줄만들기(대본읽기(대본), 한줄글자수)
    if not 큐들:
        그만("대본에서 자막으로 쓸 글을 못 찾았습니다.",
             "대본.txt 를 열어 내용이 들어있는지 확인해주세요.")
    안내("✂️  자막 %d장으로 나눴습니다." % len(큐들))

    # ── 4. 음성 분석 ────────────────────────────────
    안내("\n🎧 목소리를 분석하는 중입니다... (몇 초 걸립니다)")
    총길이 = 음성길이(ffprobe, 음성)
    if not 총길이:
        그만("음성 파일의 길이를 읽지 못했습니다.",
             "음성 파일이 제대로 내려받아졌는지 확인해주세요.\n(파일을 더블클릭해서 소리가 나는지 들어보세요)")
    무음시작, 무음끝 = 말시작지점찾기(ffmpeg, 음성) if ffmpeg else ([], [])
    # 쉼표에서 잠깐 쉬는 짧은 숨도 따로 모읍니다 (긴 문장을 쪼갠 자막을 붙일 때 씁니다)
    _, 짧은쉼 = 말시작지점찾기(ffmpeg, 음성, 기준dB=-32, 최소무음=0.08) if ffmpeg else ([], [])
    안내("   음성 길이 %.1f초 · 말이 끊기는 지점 %d곳을 찾았습니다." % (총길이, len(무음끝)))

    당김 = 숫자(설정.get("자막당김"), 0.0)
    시각들 = 시각배정(큐들, 총길이, 무음시작, 무음끝, 짧은쉼, 당김)

    # 대본과 음성이 서로 안 맞으면 미리 알려줍니다.
    # (음성을 만든 뒤에 대본을 고치면 이렇게 됩니다 — 조용히 넘어가면 나중에 더 헷갈립니다)
    마지막시작 = 시각들[-1][0]
    if 마지막시작 > 총길이 - 0.3:
        안넘김 = sum(1 for 시, _ in 시각들 if 시 > 총길이 - 0.3)
        안내("\n   ⚠️ 대본이 음성보다 깁니다 — 마지막 %d장이 영상에 안 나올 수 있습니다." % 안넘김)
        안내("      음성을 만든 그 대본이 맞는지 확인해보세요.")
        안내("      (음성을 뽑은 뒤에 대본을 고쳤다면 이렇게 됩니다)")
    elif len(큐들) >= 2 and (총길이 / len(큐들)) > 12:
        안내("\n   ⚠️ 자막 한 장이 평균 %.0f초씩 떠 있습니다 — 대본이 음성보다 짧은 것 같습니다."
             % (총길이 / len(큐들)))
        안내("      대본에 빠진 부분이 없는지 확인해보세요.")

    # ── 5. 자막 파일 만들기 ──────────────────────────
    세로영상 = 설정.get("화면크기", "가로").strip() in ("세로", "쇼츠", "숏폼")
    가로, 세로 = (1080, 1920) if 세로영상 else (1920, 1080)

    ass경로 = os.path.join(여기, "_자막.ass")
    ass만들기(큐들, 시각들, 설정, 가로, 세로, ass경로, 이미지있음=bool(이미지))
    안내("📝 자막 파일을 만들었습니다: _자막.ass")

    # 사람이 눈으로 확인할 수 있게 시각표도 남깁니다
    표경로 = os.path.join(여기, "_자막시각표.txt")
    with open(표경로, "w", encoding="utf-8") as f:
        f.write("자막이 뜨는 시각표 (분:초)\n")
        f.write("─" * 50 + "\n")
        for (원문, _, 문장시작), (시작, 끝) in zip(큐들, 시각들):
            f.write("%02d:%05.2f  %s%s\n" % (int(시작 // 60), 시작 % 60,
                                             "" if 문장시작 else "↳ ", 원문))
    안내("🕒 시각표도 남겼습니다: _자막시각표.txt")

    if 자막만:
        제목줄("✅ 자막만 만들었습니다")
        안내("_자막시각표.txt 를 열어 시각이 그럴듯한지 확인해보세요.")
        안내("영상까지 만들려면:  python 영상만들기.py")
        return

    # ── 6. 렌더 ─────────────────────────────────────
    배경색 = 색코드(설정.get("배경색"), "0D1B3E")
    이름 = "맛보기.mp4" if 맛보기 else "완성영상.mp4"
    저장경로 = os.path.join(여기, 이름)

    제목줄("🎬 이제 영상을 만듭니다")
    if 맛보기:
        안내("앞부분 40초만 빠르게 만듭니다. (보통 10~30초)")
    else:
        안내("전체 영상을 만듭니다. 음성 1분당 20~40초쯤 걸립니다.")
        안내("음성이 5분이면 2~4분 정도 — 그동안 화면이 멈춘 것처럼 보여도 정상입니다.")
    안내("\n   ⏳ 만드는 중... (이 창을 끄지 마세요)")

    코드, 오류글 = 렌더(ffmpeg, 음성, ass경로, 이미지, 배경색, 가로, 세로,
                      저장경로, 40 if 맛보기 else 0)

    if 코드 != 0:
        꼬리 = "\n".join(오류글.strip().splitlines()[-12:])
        안내("\n--- ffmpeg 가 남긴 말 (AI에게 보여주면 됩니다) ---\n" + 꼬리)
        그만("영상 만들기가 도중에 멈췄습니다.",
             "위의 영어 메시지를 통째로 복사해서 AI에게 '이게 무슨 뜻이야?' 라고 물어보세요.\n"
             "글꼴 관련 오류라면 설정.txt 에서 글자크기를 줄여보는 것도 방법입니다.")

    크기MB = os.path.getsize(저장경로) / (1024 * 1024)
    제목줄("✅ 다 됐습니다!")
    안내("📁 만들어진 파일: %s  (%.1f MB)" % (저장경로, 크기MB))
    안내("")
    안내("👀 이제 파일을 더블클릭해서 확인하세요. 볼 것은 딱 세 군데입니다:")
    안내("   ① 맨 처음 — 말이 시작될 때 자막이 같이 뜨는가")
    안내("   ② 중간쯤 — 자막이 목소리보다 빠르거나 늦지 않은가")
    안내("   ③ 맨 끝   — 마지막 자막이 말과 함께 끝나는가")
    안내("")
    안내("자막이 조금씩 밀린다면 설정.txt 의 '자막당김' 을 0.3 처럼 바꿔보세요.")
    안내("(자막이 늦게 뜨면 숫자를 키우고, 너무 일찍 뜨면 -0.3 처럼 마이너스로)")
    if 맛보기:
        안내("\n괜찮아 보이면 전체를 만드세요:  python 영상만들기.py")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n중단했습니다. 다시 하려면 같은 명령을 또 치면 됩니다.")
        sys.exit(1)
