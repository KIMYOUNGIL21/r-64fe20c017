# -*- coding: utf-8 -*-
"""
영상 키트 점검 — "왜 안 되지?" 할 때 원인을 대신 찾아주는 도구
그밤PD 챌린지 1기 · 3주차 배포 재료 (v1.0)

실행:  python 점검.py

이 도구는 아무것도 고치지 않습니다. 무엇이 문제인지 알려주기만 합니다.
"""

import sys
import os
import re
import shutil
import subprocess

try:
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
except Exception:
    pass

여기 = os.path.dirname(os.path.abspath(__file__))
재료폴더후보 = [여기, os.path.dirname(여기)]
음성확장자 = (".mp3", ".wav", ".m4a", ".aac", ".ogg", ".flac")

합격 = []
경고 = []
실패 = []


def 검사(이름, 결과, 내용, 해결=None):
    if 결과 == "ok":
        합격.append((이름, 내용))
        print("  ✅ %-22s %s" % (이름, 내용))
    elif 결과 == "warn":
        경고.append((이름, 내용, 해결))
        print("  ⚠️  %-22s %s" % (이름, 내용))
    else:
        실패.append((이름, 내용, 해결))
        print("  ❌ %-22s %s" % (이름, 내용))


print("\n" + "─" * 58)
print("  🔍 영상 키트 점검")
print("─" * 58)
print("\n[1] 프로그램")

# ── 파이썬 ────────────────────────────────────────────
버전 = "%d.%d.%d" % sys.version_info[:3]
if sys.version_info >= (3, 8):
    검사("파이썬", "ok", 버전 + " — 좋습니다")
else:
    검사("파이썬", "fail", 버전 + " — 너무 옛날 버전입니다",
         "python.org 에서 최신 파이썬을 받아 다시 설치하세요.")

# ── ffmpeg ───────────────────────────────────────────
ffmpeg = shutil.which("ffmpeg") or shutil.which("ffmpeg.exe")
if ffmpeg:
    try:
        r = subprocess.run([ffmpeg, "-version"], stdout=subprocess.PIPE,
                           stderr=subprocess.PIPE)
        첫줄 = r.stdout.decode("utf-8", "replace").splitlines()[0]
        판 = 첫줄.split(" ")[2] if len(첫줄.split(" ")) > 2 else "?"
        검사("ffmpeg", "ok", "설치됨 (%s)" % 판)
    except Exception:
        검사("ffmpeg", "ok", "설치됨")
else:
    검사("ffmpeg", "fail", "없습니다 — 영상을 만들 수 없습니다",
         "이 검은 창에 아래를 붙여넣고 엔터 (2~5분 걸립니다):\n"
         "         winget install Gyan.FFmpeg\n"
         "      설치가 끝나면 VS Code를 껐다 켜고 다시 점검하세요.")

ffprobe = shutil.which("ffprobe") or shutil.which("ffprobe.exe")
if ffprobe:
    검사("ffprobe", "ok", "설치됨")
elif ffmpeg:
    검사("ffprobe", "warn", "없지만 ffmpeg 로 대신할 수 있습니다", None)

# ── 한글 글꼴 ─────────────────────────────────────────
글꼴후보 = [
    r"C:\Windows\Fonts\malgun.ttf",
    r"C:\Windows\Fonts\malgunbd.ttf",
    "/System/Library/Fonts/AppleSDGothicNeo.ttc",
]
있는글꼴 = [p for p in 글꼴후보 if os.path.exists(p)]
if 있는글꼴:
    검사("한글 글꼴", "ok", os.path.basename(있는글꼴[0]) + " 있음")
else:
    검사("한글 글꼴", "warn", "맑은 고딕을 못 찾았습니다",
         "자막이 네모(□□□)로 나오면 설정.txt 에서 글꼴 문제입니다.\n"
         "      AI에게 '자막 글꼴을 내 컴퓨터에 있는 한글 글꼴로 바꿔줘' 라고 하세요.")

print("\n[2] 재료 (대본 · 음성)")

# ── 재료 ─────────────────────────────────────────────
# ※ 키트가 만든 '_자막시각표.txt' 를 대본으로 잡는 사고가 있었습니다.
#   밑줄(_)로 시작하는 파일은 키트의 결과물이므로 재료 후보에서 뺍니다.
제외파일 = ("readme.md", "설정.txt", "자주묻는질문.md", "requirements.txt")

대본, 음성 = None, None
찾은폴더 = None
for 폴더 in 재료폴더후보:
    if not os.path.isdir(폴더):
        continue
    대본후보, 음성후보 = [], []
    for 이름 in sorted(os.listdir(폴더)):
        전체 = os.path.join(폴더, 이름)
        if not os.path.isfile(전체):
            continue
        if 이름.lower() in 제외파일 or 이름.startswith("_") or 이름.startswith("~"):
            continue
        if 이름.lower().endswith(".txt"):
            대본후보.append(전체)
        if 이름.lower().endswith(음성확장자):
            음성후보.append(전체)
    if 대본 is None and 대본후보:
        대본 = next((p for p in 대본후보 if "대본" in os.path.basename(p)
                    or "script" in os.path.basename(p).lower()), 대본후보[0])
    if 음성 is None and 음성후보:
        음성 = next((p for p in 음성후보 if "음성" in os.path.basename(p)
                    or "voice" in os.path.basename(p).lower()), 음성후보[0])
    if 대본 and 음성:
        찾은폴더 = 폴더
        break

if 대본:
    글자 = 0
    try:
        for 인코딩 in ("utf-8", "utf-8-sig", "cp949"):
            try:
                with open(대본, "r", encoding=인코딩) as f:
                    글자 = len(f.read().strip())
                break
            except UnicodeDecodeError:
                continue
    except Exception:
        pass
    if 글자 > 0:
        검사("대본", "ok", "%s (%d글자)" % (os.path.basename(대본), 글자))
    else:
        검사("대본", "fail", "%s — 내용이 비어있습니다" % os.path.basename(대본),
             "대본.txt 를 열어 내용을 채우고 저장하세요.")
else:
    검사("대본", "fail", "대본 파일(.txt)이 없습니다",
         "대본을 '대본.txt' 로 저장해서 이 키트 폴더나 그 위 폴더에 넣으세요.")

if 음성:
    크기 = os.path.getsize(음성) / (1024 * 1024)
    길이 = None
    if ffprobe or ffmpeg:
        도구 = ffprobe or ffmpeg
        try:
            r = subprocess.run([도구, "-v", "error", "-show_entries",
                                "format=duration", "-of",
                                "default=noprint_wrappers=1:nokey=1", 음성],
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            글 = r.stdout.decode("utf-8", "replace").strip()
            if 글:
                길이 = float(글)
        except Exception:
            pass
    if 길이:
        검사("음성", "ok", "%s (%.1f MB · %d분 %d초)"
             % (os.path.basename(음성), 크기, int(길이 // 60), int(길이 % 60)))
        if 길이 < 3:
            검사("음성 길이", "warn", "3초도 안 됩니다 — 파일이 잘못 받아졌을 수 있습니다",
                 "일레븐랩스에서 다시 내려받아 보세요.")
    else:
        검사("음성", "warn", "%s (%.1f MB) — 길이를 못 읽었습니다"
             % (os.path.basename(음성), 크기),
             "파일을 더블클릭해서 소리가 나는지 들어보세요.")
else:
    검사("음성", "fail", "음성 파일(.mp3)이 없습니다",
         "일레븐랩스에서 받은 파일을 '음성.mp3' 로 저장해 넣으세요.")

if 찾은폴더:
    print("      ↳ 재료를 찾은 곳: %s" % 찾은폴더)

print("\n[3] 설정")

# ── 설정.txt ─────────────────────────────────────────
설정경로 = os.path.join(여기, "설정.txt")
if not os.path.exists(설정경로):
    검사("설정.txt", "warn", "없습니다 — 기본값으로 만들어집니다",
         "키트를 다시 받아 설정.txt 를 제자리에 두면 색을 바꿀 수 있습니다.")
else:
    설정 = {}
    try:
        with open(설정경로, "r", encoding="utf-8") as f:
            for 줄 in f:
                줄 = 줄.strip()
                if 줄 and not 줄.startswith("#") and "=" in 줄:
                    키, _, 값 = 줄.partition("=")
                    설정[키.strip()] = 값.strip()
        검사("설정.txt", "ok", "%d개 항목을 읽었습니다" % len(설정))
    except Exception as e:
        검사("설정.txt", "fail", "읽지 못했습니다 (%s)" % e,
             "메모장에서 열어 [다른 이름으로 저장] → 인코딩 UTF-8 로 저장하세요.")
        설정 = {}

    당김 = 설정.get("자막당김", "0")
    try:
        값 = float(str(당김).replace("초", "").strip())
        if abs(값) > 3:
            검사("자막당김", "warn", "%s초는 너무 큽니다" % 당김,
                 "보통 -1 ~ 1 사이입니다. 0 으로 되돌리고 0.3 씩 조절해보세요.")
        else:
            검사("자막당김", "ok", "%s초" % 값)
    except Exception:
        검사("자막당김", "fail", "'%s' 는 숫자가 아닙니다" % 당김,
             "0 또는 0.3 처럼 숫자만 적으세요.")

    이미지 = 설정.get("배경이미지", "").strip()
    if 이미지:
        찾음 = any(os.path.isfile(os.path.join(p, 이미지)) for p in 재료폴더후보)
        if 찾음:
            검사("배경이미지", "ok", 이미지)
        else:
            검사("배경이미지", "warn", "'%s' 를 못 찾았습니다" % 이미지,
                 "파일 이름이 정확한지 확인하세요(확장자 .jpg 까지).\n"
                 "      비워두면 단색 배경으로 잘 만들어집니다.")

    크기설정 = 설정.get("화면크기", "가로").strip()
    검사("화면크기", "ok", "%s (%s)" % (크기설정,
                                    "1080x1920 쇼츠" if 크기설정 in ("세로", "쇼츠", "숏폼")
                                    else "1920x1080 유튜브"))

print("\n[4] 만들어진 결과물")
for 이름 in ("완성영상.mp4", "맛보기.mp4", "_자막.ass", "_자막시각표.txt"):
    경로 = os.path.join(여기, 이름)
    if os.path.exists(경로):
        MB = os.path.getsize(경로) / (1024 * 1024)
        if MB >= 1:
            print("  · %-16s %.1f MB" % (이름, MB))
        else:
            print("  · %-16s %.0f KB" % (이름, MB * 1024))
    else:
        print("  · %-16s (아직 없음)" % 이름)

# ── 마무리 ───────────────────────────────────────────
print("\n" + "─" * 58)
if 실패:
    print("  ❌ 먼저 해결해야 할 것이 %d개 있습니다." % len(실패))
    print("─" * 58)
    for 이름, 내용, 해결 in 실패:
        print("\n  [%s] %s" % (이름, 내용))
        if 해결:
            print("   👉 %s" % 해결)
    print("\n  이 창을 통째로 캡처해서 AI에게 보여주면 같이 풀 수 있습니다.")
elif 경고:
    print("  ⚠️  큰 문제는 없지만 %d가지를 봐두세요." % len(경고))
    print("─" * 58)
    for 이름, 내용, 해결 in 경고:
        print("\n  [%s] %s" % (이름, 내용))
        if 해결:
            print("   👉 %s" % 해결)
    print("\n  이대로도 영상은 만들어집니다:  python 영상만들기.py")
else:
    print("  ✅ 전부 정상입니다. 이제 만들면 됩니다:")
    print("─" * 58)
    print("\n     python 영상만들기.py --맛보기     ← 앞부분 40초만 먼저")
    print("     python 영상만들기.py              ← 전체 영상")
print("")
